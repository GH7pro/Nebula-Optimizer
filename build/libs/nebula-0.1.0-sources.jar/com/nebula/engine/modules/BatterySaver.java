package com.nebula.engine.modules;

import com.nebula.NebulaConfig;
import com.nebula.engine.NebulaModule;
import net.minecraft.class_310;
import net.minecraft.class_4066;

public class BatterySaver implements NebulaModule {
    private static final BatterySaver INSTANCE = new BatterySaver();
    private boolean isBatterySaverActive = false;
    private int tickCounter = 0;
    
    // NOVO: Salva o FPS original do jogador para não forçar 60 se ele jogava em 120
    private int originalMaxFps = 60;
    private int originalRenderDistance = 12;
    
    private BatterySaver() {}
    
    public static BatterySaver getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Battery Saver";
    }
    
    @Override
    public void initialize() {
        System.out.println("🔋 [Nebula] Battery Saver inicializado!");
    }
    
        @Override
    public void tick() {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null) return;
        
        tickCounter++;
        
        // Verifica a cada 5 segundos (100 ticks)
        if (tickCounter % 100 != 0) return;
        
        // LÓGICA CORRIGIDA: Liga se estiver ativado na config, desliga se estiver desativado!
        if (NebulaConfig.enableBatterySaver && !isBatterySaverActive) {
            activateBatterySaver(client);
        } else if (!NebulaConfig.enableBatterySaver && isBatterySaverActive) {
            deactivateBatterySaver(client);
        }
        
        // BÔNUS: Se o jogador estiver parado (AFK), baixar o FPS para economizar bateria!
        if (isBatterySaverActive && client.field_1724.field_6012 % 100 == 0) {
            if (client.field_1724.field_5973 < 0.1) {
                client.field_1690.method_42524().method_41748(15);
            } else {
                client.field_1690.method_42524().method_41748(30);
            }
        }
    }
    
        private void activateBatterySaver(class_310 client) {
        isBatterySaverActive = true;
        
        // Salva as configurações originais do jogador antes de mudar
        try {
            originalMaxFps = client.field_1690.method_42524().method_41753();
            originalRenderDistance = client.field_1690.method_42503().method_41753();
        } catch (Exception e) {
            originalMaxFps = 60;
            originalRenderDistance = 12;
        }
        
        System.out.println("🔋 [Nebula] ⚠️ MODO ECO ATIVADO! Economizando bateria.");
        
        try {
            client.field_1690.method_42524().method_41748(30); // Limite suave para economizar
//             client.options.getViewDistance().setValue(6);
            // REMOVIDO: client.options.getGraphicsMode().setValue(GraphicsMode.FAST); -> Causava crash no mobile
            client.field_1690.method_42475().method_41748(class_4066.field_18199);
            client.field_1690.method_42435().method_41748(false);
        } catch (Exception e) {
            System.err.println("🔋 [Nebula] Erro ao ativar economia: " + e.getMessage());
        }
    }
    
        private void deactivateBatterySaver(class_310 client) {
        isBatterySaverActive = false;
        System.out.println("🔋 [Nebula] ✅ Modo Eco desativado. Restaurando config.");
        
        try {
            client.field_1690.method_42524().method_41748(originalMaxFps);
//             client.options.getViewDistance().setValue(originalRenderDistance);
            // REMOVIDO: client.options.getGraphicsMode().setValue(GraphicsMode.FANCY);
            client.field_1690.method_42475().method_41748(class_4066.field_18197);
            client.field_1690.method_42435().method_41748(true);
        } catch (Exception e) {
            System.err.println("🔋 [Nebula] Erro ao restaurar: " + e.getMessage());
        }
    }
    
    public boolean isBatterySaverActive() {
        return isBatterySaverActive;
    }
    
    @Override
    public void shutdown() {
        // Ao fechar o jogo, garante que restaura tudo
        if (isBatterySaverActive) {
            deactivateBatterySaver(class_310.method_1551());
        }
    }
    
    @Override
    public boolean isEnabled() {
        return NebulaConfig.enableNebula && NebulaConfig.enableBatterySaver;
    }
}
