package com.nebula.engine.modules;

import com.nebula.NebulaConfig;
import com.nebula.engine.NebulaModule;
import net.minecraft.class_310;
import net.minecraft.class_4066;
import net.minecraft.class_5365;
import com.nebula.PerformanceMonitor;

public class DynamicShaders implements NebulaModule {
    private static final DynamicShaders INSTANCE = new DynamicShaders();
    private boolean enabled = true;
    private int currentQuality = 2;
    private int tickCounter = 0;
    
    private static final int CHECK_INTERVAL = 40;
    
    private DynamicShaders() {}
    
    public static DynamicShaders getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Dynamic Shader Quality";
    }
    
    @Override
    public void initialize() {
        System.out.println("🎨 [Nebula] Dynamic Shaders inicializado!");
    }
    
    @Override
    public void tick() {
        if (!enabled) return;
        
        tickCounter++;
        if (tickCounter % CHECK_INTERVAL != 0) return;
        
        double fps = PerformanceMonitor.getInstance().getCurrentFPS();
        int targetFPS = NebulaConfig.get().targetFps;
        
        int newQuality = currentQuality;
        
        if (fps < targetFPS * 0.5) {
            newQuality = 0;
        } else if (fps < targetFPS * 0.7) {
            newQuality = 1;
        } else {
            newQuality = 2;
        }
        
        if (newQuality != currentQuality) {
            applyQuality(newQuality);
        }
    }
    
    private void applyQuality(int quality) {
        currentQuality = quality;
        class_310 client = class_310.method_1551();
        if (client == null) return;
        
        switch (quality) {
            case 0:
                client.field_1690.method_42534().method_41748(class_5365.field_25427);
                client.field_1690.method_42475().method_41748(class_4066.field_18199);
                System.out.println("🎨 [Nebula] Qualidade: Baixa");
                break;
                
            case 1:
                client.field_1690.method_42534().method_41748(class_5365.field_25428);
                client.field_1690.method_42475().method_41748(class_4066.field_18198);
                System.out.println("🎨 [Nebula] Qualidade: Média");
                break;
                
            case 2:
                client.field_1690.method_42534().method_41748(class_5365.field_25429);
                client.field_1690.method_42475().method_41748(class_4066.field_18197);
                System.out.println("🎨 [Nebula] Qualidade: Alta");
                break;
        }
    }
    
    @Override
    public void shutdown() {
        System.out.println("🎨 [Nebula] Dynamic Shaders desligado!");
    }
    
    @Override
    public boolean isEnabled() {
        return enabled && NebulaConfig.enableNebula && NebulaConfig.get().enableDynamicShaders;
    }
}
