package com.nebula.engine.modules;

import com.nebula.NebulaConfig;
import com.nebula.engine.NebulaModule;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_310;

public class TickSchedulingModule implements NebulaModule {
    private static final TickSchedulingModule INSTANCE = new TickSchedulingModule();
    private Map<UUID, Integer> entityTickCounter = new ConcurrentHashMap<>();
    private boolean enabled = true;
    
    private TickSchedulingModule() {}
    
    public static TickSchedulingModule getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Intelligent Tick Scheduling";
    }
    
    @Override
    public void initialize() {
        System.out.println("⏱️ [Nebula] Tick Scheduling Module inicializado!");
    }
    
    @Override
    public void tick() {
        // Limpa o cache periodicamente
        if (entityTickCounter.size() > 1000) {
            entityTickCounter.clear();
        }
    }
    
    public boolean shouldTickEntity(class_1297 entity) {
        if (!enabled) return true;
        
        NebulaConfig config = NebulaConfig.get();
        if (!config.enableIntelligentTicking) return true;
        
        // Sempre atualiza o jogador
        if (entity instanceof class_1657) return true;
        
        try {
            class_310 client = class_310.method_1551();
            if (client == null || client.field_1724 == null) return true;
            
            UUID id = entity.method_5667();
            double distance = client.field_1724.method_5739(entity);
            int reductionDistance = config.entityTickReductionDistance;
            
            // Entidades muito distantes: NUNCA atualizam (já é tratado no Mixin)
            if (distance > reductionDistance) {
                return false;
            }
            
            // Entidades moderadamente distantes: atualiza a cada 2 ticks
            if (distance > 30) {
                int counter = entityTickCounter.getOrDefault(id, 0);
                if (counter >= 2) {
                    entityTickCounter.put(id, 0);
                    return true;
                } else {
                    entityTickCounter.put(id, counter + 1);
                    return false;
                }
            }
            
            // Entidades próximas: atualiza normalmente
            return true;
            
        } catch (Exception e) {
            return true;
        }
    }
    
    @Override
    public void shutdown() {
        entityTickCounter.clear();
        System.out.println("⏱️ [Nebula] Tick Scheduling Module desligado!");
    }
    
    @Override
    public boolean isEnabled() {
        return enabled && NebulaConfig.enableNebula && NebulaConfig.get().enableIntelligentTicking;
    }
    
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
}
