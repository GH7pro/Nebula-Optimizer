package com.nebula.engine.modules;

import com.nebula.NebulaConfig;
import com.nebula.engine.NebulaModule;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;

public class SelectiveCulling implements NebulaModule {
    private static final SelectiveCulling INSTANCE = new SelectiveCulling();
    private boolean enabled = true;
    
    private SelectiveCulling() {}
    
    public static SelectiveCulling getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Selective Render Culling";
    }
    
    @Override
    public void initialize() {
        System.out.println("🧩 [Nebula] Selective Culling inicializado!");
    }
    
    @Override
    public void tick() {
        // O trabalho real seria feito nos Mixins de renderização
    }
    
    public boolean shouldRender(class_1297 entity, class_243 cameraDirection) {
        if (!enabled) return true;
        if (!NebulaConfig.get().enableSelectiveCulling) return true;
        
        class_243 entityPos = entity.method_19538();
        class_243 cameraPos = class_310.method_1551().field_1724.method_19538();
        
        class_243 toEntity = entityPos.method_1020(cameraPos).method_1029();
        double angle = Math.acos(cameraDirection.method_1026(toEntity));
        double angleDegrees = Math.toDegrees(angle);
        
        // Foco central (45 graus): renderiza completo
        if (angleDegrees < 45) {
            return true;
        }
        
        // Periferia (45-90 graus): renderiza com qualidade reduzida
        if (angleDegrees < 90) {
            return true; // Reduz qualidade
        }
        
        // Fora do campo de visão: não renderiza
        return false;
    }
    
    @Override
    public void shutdown() {
        System.out.println("🧩 [Nebula] Selective Culling desligado!");
    }
    
    @Override
    public boolean isEnabled() {
        return enabled && NebulaConfig.get().enableSelectiveCulling;
    }
}
