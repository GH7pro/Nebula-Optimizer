package com.nebula.engine.modules;

import com.nebula.NebulaConfig;
import com.nebula.engine.NebulaModule;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class SprintOptimizer implements NebulaModule {
    private static final SprintOptimizer INSTANCE = new SprintOptimizer();
    private boolean enabled = true;
    private int tickCounter = 0;
    private boolean wasSprinting = false;
    
    // Configurações
    private static final int CHECK_INTERVAL = 10; // A cada 0.5 segundos
    private static final int SPRINT_RENDER_DISTANCE = 8; // Render distance durante corrida
    
    private SprintOptimizer() {}
    
    public static SprintOptimizer getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Sprint Optimization";
    }
    
    @Override
    public void initialize() {
        System.out.println("🏃 [Nebula] Sprint Optimizer inicializado!");
    }
    
    @Override
    public void tick() {
        if (!enabled || !NebulaConfig.enableSprintOptimization) return;
        
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null) return;
        
        tickCounter++;
        if (tickCounter % CHECK_INTERVAL != 0) return;
        
        class_746 player = client.field_1724;
        boolean isSprinting = player.method_5624();
        
        if (isSprinting && !wasSprinting) {
            enterSprintMode(client);
            wasSprinting = true;
        } else if (!isSprinting && wasSprinting) {
            exitSprintMode(client);
            wasSprinting = false;
        }
    }
    
    private void enterSprintMode(class_310 client) {
        if (NebulaConfig.debugMode) {
            System.out.println("🏃 [Nebula] 🏃 Correndo! Ativando otimizações...");
        }
        
        try {
            // ===== REDUZ DISTÂNCIA DE RENDERIZAÇÃO =====
            int currentDistance = client.field_1690.method_42503().method_41753();
            if (currentDistance > SPRINT_RENDER_DISTANCE) {
//                 client.options.getViewDistance().setValue(SPRINT_RENDER_DISTANCE);
                if (NebulaConfig.debugMode) {
                    System.out.println("🏃 [Nebula] ✅ Render distance: " + SPRINT_RENDER_DISTANCE);
                }
            }
            
            // ===== REDUZ FPS DURANTE CORRIDA =====
            int currentFps = client.field_1690.method_42524().method_41753();
            if (currentFps > 45) {
                client.field_1690.method_42524().method_41748(45);
                if (NebulaConfig.debugMode) {
                    System.out.println("🏃 [Nebula] ✅ FPS limitado a 45");
                }
            }
            
        } catch (Exception e) {
            if (NebulaConfig.debugMode) {
                System.err.println("🏃 [Nebula] Erro ao ativar modo corrida: " + e.getMessage());
            }
        }
    }
    
    private void exitSprintMode(class_310 client) {
        if (NebulaConfig.debugMode) {
            System.out.println("🏃 [Nebula] 🚶 Parou de correr! Restaurando...");
        }
        
        try {
            // ===== RESTAURA DISTÂNCIA (para o que o jogador realmente escolheu, não um número fixo) =====
//             client.options.getViewDistance().setValue(NebulaConfig.userRenderDistance);
            
            // ===== RESTAURA FPS =====
            client.field_1690.method_42524().method_41748(60);
            
            if (NebulaConfig.debugMode) {
                System.out.println("🏃 [Nebula] ✅ Configurações restauradas!");
            }
            
        } catch (Exception e) {
            if (NebulaConfig.debugMode) {
                System.err.println("🏃 [Nebula] Erro ao restaurar: " + e.getMessage());
            }
        }
    }
    
    @Override
    public void shutdown() {
        System.out.println("🏃 [Nebula] Sprint Optimizer desligado!");
    }
    
    @Override
    public boolean isEnabled() {
        return enabled && NebulaConfig.enableSprintOptimization;
    }
}
