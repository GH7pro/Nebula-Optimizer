package com.nebula.engine.modules;

import com.nebula.NebulaConfig;
import com.nebula.engine.NebulaModule;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2791;
import net.minecraft.class_310;

public class SmartChunkLoader implements NebulaModule {
    private static final SmartChunkLoader INSTANCE = new SmartChunkLoader();
    private class_243 lastPosition = null;
    private class_243 velocity = class_243.field_1353;
    private class_2350 lastDirection = class_2350.field_11043;
    private Set<class_2791> preloadedChunks = new HashSet<>();
    private boolean enabled = true;
    
    private static final int PREDICT_DISTANCE = 8;
    private static final int MAX_PRELOAD = 16;
    
    private SmartChunkLoader() {}
    
    public static SmartChunkLoader getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Smart Chunk Loading";
    }
    
    @Override
    public void initialize() {
        System.out.println("🔮 [Nebula] Smart Chunk Loader inicializado!");
    }
    
    @Override
    public void tick() {
        if (!enabled) return;
        
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null || client.field_1687 == null) return;
        
        class_243 currentPos = client.field_1724.method_19538();
        
        if (lastPosition == null) {
            lastPosition = currentPos;
            return;
        }
        
        // Calcula velocidade e direção
        velocity = currentPos.method_1020(lastPosition);
        lastPosition = currentPos;
        
        if (velocity.method_1033() > 0.1) {
            class_2350 direction = class_2350.method_50026((int)velocity.field_1352, (int)velocity.field_1351, (int)velocity.field_1350);
            if (direction != null) {
                lastDirection = direction;
                predictAndPreload(client);
            }
        }
    }
    
    private void predictAndPreload(class_310 client) {
        class_243 playerPos = client.field_1724.method_19538();
        int chunkX = (int)(playerPos.field_1352 / 16);
        int chunkZ = (int)(playerPos.field_1350 / 16);
        
        // Calcula chunks na direção do movimento
        int dx = lastDirection.method_10148() * PREDICT_DISTANCE;
        int dz = lastDirection.method_10165() * PREDICT_DISTANCE;
        
        int targetX = chunkX + dx;
        int targetZ = chunkZ + dz;
        
        // Pré-carrega chunks ao longo do caminho
        for (int i = 0; i < PREDICT_DISTANCE; i++) {
            int cx = chunkX + (dx / PREDICT_DISTANCE) * i;
            int cz = chunkZ + (dz / PREDICT_DISTANCE) * i;
            
            if (!client.field_1687.method_8393(cx, cz)) {
                // Inicia carregamento assíncrono
                client.field_1687.method_2935().method_12246(cx, cz);
                
                if (NebulaConfig.get().debugMode) {
                    System.out.println("🔮 [Nebula] Pré-carregando chunk: [" + cx + ", " + cz + "]");
                }
            }
        }
    }
    
    @Override
    public void shutdown() {
        preloadedChunks.clear();
        System.out.println("🔮 [Nebula] Smart Chunk Loader desligado!");
    }
    
    @Override
    public boolean isEnabled() {
        return enabled && NebulaConfig.enableNebula && NebulaConfig.get().enableSmartChunkLoading;
    }
}
