package com.nebula.engine.modules;

import com.nebula.NebulaConfig;
import com.nebula.engine.NebulaModule;
import net.minecraft.class_310;
import net.minecraft.class_4066;

public class DimensionOptimizer implements NebulaModule {
    private static final DimensionOptimizer INSTANCE = new DimensionOptimizer();
    private boolean enabled = true;
    private String currentDimension = "overworld";
    
    private DimensionOptimizer() {}
    
    public static DimensionOptimizer getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Dimension Optimizer";
    }
    
    @Override
    public void initialize() {
        System.out.println("🌍 [Nebula] Dimension Optimizer inicializado!");
    }
    
    @Override
    public void tick() {
        if (!enabled) return;
        
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null || client.field_1687 == null) return;
        
        String dim = client.field_1687.method_44013().method_29177().method_12832();
        
        if (!dim.equals(currentDimension)) {
            currentDimension = dim;
            optimizeDimension(dim);
        }
    }
    
    private void optimizeDimension(String dimension) {
        System.out.println("🌍 [Nebula] Otimizando dimensão: " + dimension);
        
        class_310 client = class_310.method_1551();
        if (client == null) return;
        
        switch (dimension) {
            case "the_nether":
                client.field_1690.method_42475().method_41748(class_4066.field_18198);
//                 client.options.getViewDistance().setValue(10);
                System.out.println("🌍 [Nebula] 🔥 Nether: Partículas reduzidas");
                break;
                
            case "the_end":
//                 client.options.getViewDistance().setValue(12);
                System.out.println("🌍 [Nebula] 🌌 End: Otimizações aplicadas");
                break;
                
            default:
                client.field_1690.method_42475().method_41748(class_4066.field_18197);
//                 client.options.getViewDistance().setValue(12);
                System.out.println("🌍 [Nebula] 🌿 Overworld: Configurações normais");
                break;
        }
    }
    
    @Override
    public void shutdown() {
        System.out.println("🌍 [Nebula] Dimension Optimizer desligado!");
    }
    
    @Override
    public boolean isEnabled() {
        return enabled && NebulaConfig.get().enableDimensionOptimizer;
    }
}
