package com.nebula.engine.modules;

import com.nebula.NebulaConfig;
import com.nebula.engine.NebulaModule;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_310;

public class EntityLOD implements NebulaModule {
    private static final EntityLOD INSTANCE = new EntityLOD();
    private boolean enabled = true;
    private ConcurrentHashMap<UUID, Integer> entityLODLevel = new ConcurrentHashMap<>();
    
    private static final int LOD_FULL = 2;
    private static final int LOD_SIMPLE = 1;
    private static final int LOD_MINIMAL = 0;
    
    private EntityLOD() {}
    
    public static EntityLOD getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Entity LOD System";
    }
    
    @Override
    public void initialize() {
        System.out.println("🎯 [Nebula] Entity LOD System inicializado!");
    }
    
    @Override
    public void tick() {
        if (!enabled) return;
        
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null || client.field_1687 == null) return;
        
        for (class_1297 entity : client.field_1687.method_18112()) {
            if (entity == client.field_1724) continue;
            
            double distance = client.field_1724.method_5739(entity);
            UUID id = entity.method_5667();
            int newLOD = calculateLOD(distance);
            int currentLOD = entityLODLevel.getOrDefault(id, LOD_FULL);
            
            if (newLOD != currentLOD) {
                applyLOD(entity, newLOD);
                entityLODLevel.put(id, newLOD);
            }
        }
    }
    
    private int calculateLOD(double distance) {
        if (distance < 20) {
            return LOD_FULL;
        } else if (distance < 50) {
            return LOD_SIMPLE;
        } else {
            return LOD_MINIMAL;
        }
    }
    
    private void applyLOD(class_1297 entity, int lod) {
        // Em 1.20.1, não temos setAiDisabled diretamente
        // Usamos a abordagem de desativar AI via NBT ou simplesmente ignoramos
        // O culling já faz um bom trabalho
        
        if (lod == LOD_MINIMAL && entity instanceof class_1308) {
            // MobEntity tem setAiDisabled
            try {
                ((class_1308) entity).method_5977(true);
            } catch (Exception e) {
                // Ignora
            }
        } else if (entity instanceof class_1308) {
            try {
                ((class_1308) entity).method_5977(false);
            } catch (Exception e) {
                // Ignora
            }
        }
    }
    
    @Override
    public void shutdown() {
        entityLODLevel.clear();
        System.out.println("🎯 [Nebula] Entity LOD System desligado!");
    }
    
    @Override
    public boolean isEnabled() {
        return enabled && NebulaConfig.enableNebula && NebulaConfig.get().enableEntityLOD;
    }
}
