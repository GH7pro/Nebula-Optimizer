package com.nebula.engine.modules;

import com.nebula.NebulaConfig;
import com.nebula.engine.NebulaModule;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_5365;

public class NightVisionOptimizer implements NebulaModule {
    private static final NightVisionOptimizer INSTANCE = new NightVisionOptimizer();
    private boolean enabled = true;
    private int tickCounter = 0;
    private boolean wasNight = false;
    private class_5365 originalGraphicsMode = class_5365.field_25428;
    private int originalBrightness = 50;
    
    private NightVisionOptimizer() {}
    
    public static NightVisionOptimizer getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Night Vision Optimizer";
    }
    
    @Override
    public void initialize() {
        System.out.println("🌙 [Nebula] Night Vision Optimizer inicializado!");
    }
    
    @Override
    public void tick() {
        if (!enabled || !NebulaConfig.enableNightVisionOptimizer) return;
        
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null || client.field_1687 == null) return;
        
        tickCounter++;
        if (tickCounter % 40 != 0) return;
        
        class_1937 world = client.field_1687;
        long time = world.method_8532() % 24000;
        boolean isNight = time > 13000 && time < 23000;
        
        if (isNight && !wasNight) {
            enterNightMode(client);
            wasNight = true;
        } else if (!isNight && wasNight) {
            exitNightMode(client);
            wasNight = false;
        }
    }
    
    private void enterNightMode(class_310 client) {
        if (NebulaConfig.debugMode) {
            System.out.println("🌙 [Nebula] 🌃 Noite detectada! Ativando otimizações...");
        }
        
        try {
            // ===== SALVA CONFIGURAÇÕES ORIGINAIS =====
            originalGraphicsMode = client.field_1690.method_42534().method_41753();
            
            // ===== REDUZ QUALIDADE GRÁFICA =====
            // Gráficos: FAST (menos processamento de luz)
            client.field_1690.method_42534().method_41748(class_5365.field_25427);
            
            // Aumenta brilho (menos processamento de sombras)
            client.field_1690.method_42473().method_41748(1.5);
            
            if (NebulaConfig.debugMode) {
                System.out.println("🌙 [Nebula] ✅ Gráficos: FAST");
            }
            
        } catch (Exception e) {
            if (NebulaConfig.debugMode) {
                System.err.println("🌙 [Nebula] Erro ao ativar modo noturno: " + e.getMessage());
            }
        }
    }
    
    private void exitNightMode(class_310 client) {
        if (NebulaConfig.debugMode) {
            System.out.println("🌙 [Nebula] ☀️ Dia! Restaurando configurações...");
        }
        
        try {
            // ===== RESTAURA CONFIGURAÇÕES =====
            client.field_1690.method_42534().method_41748(originalGraphicsMode);
            client.field_1690.method_42473().method_41748(0.5);
            
            if (NebulaConfig.debugMode) {
                System.out.println("🌙 [Nebula] ✅ Configurações restauradas!");
            }
            
        } catch (Exception e) {
            if (NebulaConfig.debugMode) {
                System.err.println("🌙 [Nebula] Erro ao restaurar: " + e.getMessage());
            }
        }
    }
    
    @Override
    public void shutdown() {
        System.out.println("🌙 [Nebula] Night Vision Optimizer desligado!");
    }
    
    @Override
    public boolean isEnabled() {
        return enabled && NebulaConfig.enableNightVisionOptimizer;
    }
}
