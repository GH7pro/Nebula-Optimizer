package com.nebula.gamemodes;

import com.nebula.NebulaConfig;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;

public class GameModeDetector {
    private static final GameModeDetector INSTANCE = new GameModeDetector();
    private GameMode currentMode = GameMode.EXPLORING;
    private int tickCounter = 0;
    private class_243 lastPosition = class_243.field_1353;
    private int stationaryTicks = 0;
    
    public enum GameMode {
        COMBAT("⚔️ Combate"),
        BUILDING("🏗️ Construção"),
        EXPLORING("🗺️ Explorando"),
        MINING("⛏️ Minerando"),
        AFK("💤 Parado"),
        UNKNOWN("❓ Desconhecido");
        
        private final String displayName;
        
        GameMode(String displayName) {
            this.displayName = displayName;
        }
        
        public String getDisplayName() {
            return displayName;
        }
    }
    
    private GameModeDetector() {}
    
    public static GameModeDetector getInstance() {
        return INSTANCE;
    }
    
    public void tick() {
        if (!NebulaConfig.enableGameModeDetection) return;
        
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null || client.field_1687 == null) return;
        
        tickCounter++;
        if (tickCounter % 20 != 0) return; // A cada 1 segundo
        
        class_1657 player = client.field_1724;
        class_243 currentPos = player.method_19538();
        
        // ===== 1. DETECTA SE ESTÁ PARADO =====
        if (currentPos.method_1022(lastPosition) < 0.1) {
            stationaryTicks++;
        } else {
            stationaryTicks = 0;
        }
        
        lastPosition = currentPos;
        
        // ===== 2. DETECTA COMBATE =====
        boolean inCombat = detectCombat(player);
        
        // ===== 3. DETECTA CONSTRUÇÃO =====
        boolean isBuilding = detectBuilding(client);
        
        // ===== 4. DETECTA MINERAÇÃO =====
        boolean isMining = detectMining(client);
        
        // ===== 5. DETERMINA O MODO =====
        GameMode newMode = currentMode;
        
        if (stationaryTicks > 300) { // 15 segundos parado
            newMode = GameMode.AFK;
        } else if (inCombat) {
            newMode = GameMode.COMBAT;
        } else if (isBuilding) {
            newMode = GameMode.BUILDING;
        } else if (isMining) {
            newMode = GameMode.MINING;
        } else if (stationaryTicks < 100) {
            newMode = GameMode.EXPLORING;
        }
        
        if (newMode != currentMode) {
            currentMode = newMode;
            onModeChange();
        }
    }
    
    private boolean detectCombat(class_1657 player) {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1687 == null) return false;
        
        for (class_1297 entity : client.field_1687.method_18112()) {
            if (entity == player) continue;
            if (entity instanceof class_1308) {
                double distance = player.method_5739(entity);
                if (distance < 10) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private boolean detectBuilding(class_310 client) {
        if (client.field_1765 != null && 
            client.field_1765.method_17783() == class_239.class_240.field_1332) {
            class_3965 hit = (class_3965) client.field_1765;
            if (client.field_1761 != null) {
                return true;
            }
        }
        return false;
    }
    
    private boolean detectMining(class_310 client) {
        if (client.field_1765 != null && 
            client.field_1765.method_17783() == class_239.class_240.field_1332) {
            if (client.field_1724 != null && client.field_1724.method_6047() != null) {
                String itemName = client.field_1724.method_6047().method_7909().toString().toLowerCase();
                if (itemName.contains("pickaxe") || 
                    itemName.contains("axe") || 
                    itemName.contains("shovel") ||
                    itemName.contains("sword")) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private void onModeChange() {
        System.out.println("🔄 [Nebula] Modo de jogo: " + currentMode.getDisplayName());
    }
    
    public GameMode getCurrentMode() {
        return currentMode;
    }
}
