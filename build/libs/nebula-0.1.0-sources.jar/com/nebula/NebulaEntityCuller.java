package com.nebula;

import com.nebula.lib.api.BudgetAPI;
import com.nebula.lib.api.CullingAPI;
import com.nebula.lib.api.FocusAPI;
import com.nebula.lib.api.ImportanceAPI;
import net.minecraft.class_1297;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;

public class NebulaEntityCuller {

    private final class_243 cameraPos;
    private final class_243 lookVec;
    private final double renderDistanceSq;

    public NebulaEntityCuller(class_4184 camera) {
        this.cameraPos = camera.method_19326();
        this.lookVec = new class_243(
            camera.method_19335().get(0),
            0,
            camera.method_19335().get(2)
        ).method_1029();

        // Distância base da CullingAPI + multiplicador do Focus Mode
        double base = CullingAPI.getEntityRenderDistance() * 16.0;
        double focusMul = FocusAPI.getFocusDistanceMultiplier();
        double adjusted = base * focusMul;
        this.renderDistanceSq = adjusted * adjusted;
    }

    public boolean shouldRenderEntity(class_1297 entity) {
        if (!CullingAPI.isEntityCullingEnabled()) return true;
        if (entity == null || !entity.method_5805()) return false;

        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null) return true;

        // Nunca corta o jogador local
        if (entity instanceof class_1657 && entity == client.field_1724) {
            return true;
        }

        // Budget: se já renderizou demais neste frame, corta
        if (!BudgetAPI.tryConsume()) {
            return false;
        }

        double distSq = entity.method_5707(cameraPos);
        double distance = Math.sqrt(distSq);

        // Direção da entidade
        class_243 toEntity = entity.method_19538().method_1020(cameraPos).method_1029();
        double dot = lookVec.method_1026(toEntity);

        // Focus Mode: ângulo mais restrito quando parado
        if (FocusAPI.isFocused() && dot < FocusAPI.getFocusAngleThreshold()) {
            // Ainda assim não corta CRITICAL
            ImportanceAPI.Priority p = classify(entity, distance);
            if (p != ImportanceAPI.Priority.CRITICAL) {
                return false;
            }
        }

        // Classifica importância
        ImportanceAPI.Priority priority = classify(entity, distance);

        // Culling por importância
        if (ImportanceAPI.shouldCull(priority, distSq, dot)) {
            return false;
        }

        // Fallback: distância pura
        if (distSq > renderDistanceSq && priority != ImportanceAPI.Priority.CRITICAL) {
            return false;
        }

        // Agressivo (só em LOW/NORMAL)
        if (CullingAPI.isAggressiveCullingEnabled()
                && distSq > 1600
                && priority != ImportanceAPI.Priority.CRITICAL
                && priority != ImportanceAPI.Priority.HIGH) {
            return false;
        }

        return true;
    }

    private ImportanceAPI.Priority classify(class_1297 entity, double distance) {
        boolean isPlayer = entity instanceof class_1657;
        boolean hostile = entity instanceof class_1588;
        String type = entity.method_5864().toString().toLowerCase();
        return ImportanceAPI.classify(type, distance, hostile, isPlayer);
    }
}
