package com.nebula.mixin;

import net.minecraft.class_1542;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_916;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_916.class)
public class ItemEntityRendererMixin {

    // Injeta nosso código no momento exato em que o Minecraft vai desenhar um item no chão
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void nebula$cullFarItems(class_1542 entity, float x, float y, float z, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        
        // Se o jogador estiver no jogo
        if (client.field_1724 != null) {
            // Calcula a distância do jogador até o item ao quadrado (é mais rápido que calcular a raiz)
            double distanceSq = entity.method_5858(client.field_1724);
            
            // Se o item estiver a mais de 15 blocos de distância (15^2 = 225)
            if (distanceSq > 225.0) {
                // Cancela o desenho! O Minecraft não perde tempo renderizando isso.
                ci.cancel();
            }
        }
    }
}
