package com.nebula.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_329;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class OverlayMixin {

    // Colocando o descritor exato (DrawContext, Entity) para o Mixin achar o método na 1.20.1
    @Inject(method = "renderVignette(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/entity/Entity;)V", at = @At("HEAD"), cancellable = true)
    private void nebula$removeVignette(class_332 context, class_1297 entity, CallbackInfo ci) {
        ci.cancel();
    }
}
