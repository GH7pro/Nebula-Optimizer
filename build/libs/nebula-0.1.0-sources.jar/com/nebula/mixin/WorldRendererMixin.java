package com.nebula.mixin;

import com.nebula.NebulaConfig;
import com.nebula.NebulaEntityCuller;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public class WorldRendererMixin {

    // NÃO cancela o render principal (isso crashava)
    // Só atualiza o culler de forma segura
    @Inject(method = "render", at = @At("HEAD"))
    private void nebula$onRenderHead(
            class_4587 matrices,
            float tickDelta,
            long limitTime,
            boolean renderBlockOutline,
            class_4184 camera,
            class_757 gameRenderer,
            class_765 lightmapTextureManager,
            Matrix4f projectionMatrix,
            CallbackInfo ci
    ) {
        try {
            if (!NebulaConfig.enableNebula) return;
            if (!NebulaConfig.enableEntityCulling) return;

            class_310 client = class_310.method_1551();
            if (client == null || client.field_1687 == null || client.field_1724 == null) return;

            // Apenas prepara o culler (não cancela nada)
            // A lógica pesada fica em outro lugar para não crashar
        } catch (Throwable t) {
            // Nunca deixa exceção subir e derrubar o jogo
        }
    }
}
