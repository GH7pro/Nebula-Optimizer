package com.nebula.mixin;

import com.nebula.gui.NebulaVideoSettingsScreen;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_437;
import net.minecraft.class_446;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_446.class)
public class VideoSettingsScreenMixin {

    // Guarda a tela REAL que pediu pra abrir o menu de vídeo (normalmente a
    // tela de "Options"). Precisa ser capturada aqui, no construtor — porque
    // quando init() roda, client.currentScreen já foi trocado pra ESTA
    // VideoOptionsScreen, então usar client.currentScreen como "parent"
    // (como era feito antes) apontava pra ela mesma, não pra tela anterior.
    // Isso fazia o botão "Done" não voltar pro lugar certo.
    @Unique
    private class_437 nebula$realParent;

    @Inject(method = "<init>", at = @At("RETURN"))
    private void nebula$captureParent(class_437 parent, class_315 gameOptions, CallbackInfo ci) {
        this.nebula$realParent = parent;
    }

    @Inject(method = "init", at = @At("HEAD"), cancellable = true)
    private void onInit(CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client != null) {
            class_315 options = client.field_1690;
            client.method_1507(new NebulaVideoSettingsScreen(this.nebula$realParent, options));
            ci.cancel();
        }
    }
}
