package com.nebula.mixin;

import com.nebula.network.AntiGhostBlock;
import net.minecraft.class_2338;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_636.class)
public class ClientPlayerInteractionMixin {
    
    @Inject(method = "breakBlock", at = @At("HEAD"))
    private void onBreakBlock(class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        // Marca o bloco para monitoramento anti-ghost
        AntiGhostBlock.getInstance().markBlockForBreaking(pos);
    }
}
