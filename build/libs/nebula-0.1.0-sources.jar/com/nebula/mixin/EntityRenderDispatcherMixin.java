package com.nebula.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_898.class)
public class EntityRenderDispatcherMixin {

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private <E extends class_1297> void nebula$cullFarEntities(E entity, double x, double y, double z, float tickDelta, float cameraYaw, class_4587 matrices, class_4597 vertexConsumers, int light, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        
        // Nunca esconde o próprio jogador
        if (entity == client.field_1724) return;

        if (client.field_1724 != null) {
            double distanceSq = entity.method_5858(client.field_1724);
            // Não desenha nenhuma entidade a mais de 25 blocos de distância
            if (distanceSq > 625.0) {
                ci.cancel();
            }
        }
    }
}
