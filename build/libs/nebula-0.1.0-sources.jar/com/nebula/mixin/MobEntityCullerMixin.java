package com.nebula.mixin;

import com.nebula.engine.modules.ThermalCuller;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1308.class)
public class MobEntityCullerMixin {

    /**
     * Intercepta o "tick" de IA dos mobs. Se o ThermalCuller estiver ativo
     * e o mob estiver a mais de 24 blocos do jogador, cancelamos o tick.
     * O mob fica paradinho, economizando CPU e evitando que o celular esquente.
     */
    @Inject(method = "tick", at = @At("HEAD"), cancellable = true)
    private void nebula$freezeMobAi(CallbackInfo ci) {
        if (ThermalCuller.shouldFreezeEntities) {
            class_310 client = class_310.method_1551();
            if (client != null && client.field_1724 != null) {
                // Converte a classe para Entity para poder medir a distância
                class_1297 mob = (class_1297) (Object) this;
                
                // Se o mob estiver longe do jogador, congela!
                if (mob.method_5739(client.field_1724) > 24.0f) {
                    ci.cancel();
                }
            }
        }
    }
}
