package com.nebula.mixin;

import net.minecraft.class_2960;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * GameRenderer#loadPostProcessor(Identifier) e #disablePostProcessor()
 * existem no vanilla mas não são public — só acessíveis dentro do próprio
 * pacote do Minecraft. Um Mixin @Invoker cria uma "ponte" pública pra esses
 * métodos, sem precisar reescrever nada do GameRenderer.
 */
@Mixin(class_757.class)
public interface GameRendererAccessor {

    @Invoker("loadPostProcessor")
    void nebula$loadPostProcessor(class_2960 id);

    @Invoker("disablePostProcessor")
    void nebula$disablePostProcessor();
}
