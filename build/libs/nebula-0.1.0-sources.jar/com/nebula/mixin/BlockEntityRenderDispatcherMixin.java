package com.nebula.mixin;

import com.nebula.NebulaConfig;
import com.nebula.lib.api.CullingAPI;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_824;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_824.class)
public class BlockEntityRenderDispatcherMixin {

    @Inject(method = "render(Lnet/minecraft/block/entity/BlockEntity;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;)V",
            at = @At("HEAD"), cancellable = true)
    private void nebula$cullBlockEntity(class_2586 blockEntity, float tickDelta, class_4587 matrices,
                                        class_4597 vertexConsumers, CallbackInfo ci) {
        try {
            if (!NebulaConfig.enableNebula) return;
            if (!NebulaConfig.enableBlockEntityCulling) return;
            if (!CullingAPI.isBlockCullingEnabled()) return;
            if (blockEntity == null) return;

            class_310 client = class_310.method_1551();
            if (client == null || client.field_1724 == null) return;

            class_2338 pos = blockEntity.method_11016();
            class_243 playerPos = client.field_1724.method_19538();

            double dx = pos.method_10263() + 0.5 - playerPos.field_1352;
            double dy = pos.method_10264() + 0.5 - playerPos.field_1351;
            double dz = pos.method_10260() + 0.5 - playerPos.field_1350;
            double distSq = dx * dx + dy * dy + dz * dz;

            double max = CullingAPI.getBlockCullingDistance() * 16.0;
            if (distSq > max * max) {
                ci.cancel();
            }
        } catch (Throwable ignored) {
        }
    }
}
