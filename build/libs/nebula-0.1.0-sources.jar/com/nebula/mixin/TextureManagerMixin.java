package com.nebula.mixin;

import com.nebula.engine.modules.TextureStreamingModule;
import net.minecraft.class_1060;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1060.class)
public class TextureManagerMixin {
    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        TextureStreamingModule.getInstance().tick();
    }
}
