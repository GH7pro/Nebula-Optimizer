package com.nebula.fullbright;

import com.nebula.NebulaConfig;
import com.nebula.engine.NebulaModule;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class FullbrightToggle implements NebulaModule {
    private static final FullbrightToggle INSTANCE = new FullbrightToggle();
    private boolean enabled = true;
    private boolean isActive = false;
    private double originalGamma = 0.5;
    private class_304 fullbrightKey;
    
    private FullbrightToggle() {}
    
    public static FullbrightToggle getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Fullbright Toggle";
    }
    
    @Override
    public void initialize() {
        System.out.println("🌙 [Nebula] Fullbright Toggle inicializado!");
        if (!NebulaConfig.enableFullbrightToggle) return;
        
        fullbrightKey = new class_304(
            "key.nebula.fullbright",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_B,
            "key.category.nebula"
        );
        
        System.out.println("🌙 [Nebula] ✅ Fullbright ativado! Pressione B para alternar");
    }
    
    @Override
    public void tick() {
        if (!enabled || !NebulaConfig.enableFullbrightToggle) return;
        
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1690 == null) return;
        
        if (fullbrightKey.method_1436()) {
            isActive = !isActive;
            if (isActive) {
                originalGamma = client.field_1690.method_42473().method_41753();
                client.field_1690.method_42473().method_41748(10.0);
                System.out.println("🌙 [Nebula] ✅ Night Vision ativada!");
            } else {
                client.field_1690.method_42473().method_41748(originalGamma);
                System.out.println("🌙 [Nebula] ❌ Night Vision desativada!");
            }
        }
    }
    
    public boolean isActive() {
        return isActive;
    }
    
    @Override
    public void shutdown() {
        class_310 client = class_310.method_1551();
        if (client != null && client.field_1690 != null) {
            client.field_1690.method_42473().method_41748(originalGamma);
        }
        System.out.println("🌙 [Nebula] Fullbright Toggle desligado!");
    }
    
    @Override
    public boolean isEnabled() {
        return enabled && NebulaConfig.enableFullbrightToggle;
    }
}
