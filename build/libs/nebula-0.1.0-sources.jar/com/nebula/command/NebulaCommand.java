package com.nebula.command;

import com.nebula.gui.NebulaSettingsScreen;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;

public class NebulaCommand {
    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommandManager.literal("nebula")
                .executes(context -> {
                    if (context.getSource().getClient().field_1724 != null) {
                        context.getSource().getClient().method_1507(
                            new NebulaSettingsScreen(context.getSource().getClient().field_1755)
                        );
                    }
                    return 1;
                })
            );
        });
    }
}
