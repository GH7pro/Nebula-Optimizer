package com.nebula.block;

import com.nebula.NebulaConfig;
import com.nebula.engine.NebulaModule;
import net.minecraft.class_310;
import net.minecraft.class_636;

public class FasterBlockBreaking implements NebulaModule {
    private static final FasterBlockBreaking INSTANCE = new FasterBlockBreaking();
    private boolean enabled = true;
    
    private FasterBlockBreaking() {}
    
    public static FasterBlockBreaking getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Faster Block Breaking";
    }
    
    @Override
    public void initialize() {
        System.out.println("⚡ [Nebula] Faster Block Breaking inicializado!");
        if (!NebulaConfig.enableFasterBlockBreaking) return;
        
        System.out.println("⚡ [Nebula] ✅ Quebra de blocos acelerada!");
    }
    
    @Override
    public void tick() {
        if (!enabled || !NebulaConfig.enableFasterBlockBreaking) return;
        
        class_310 client = class_310.method_1551();
        if (client == null) return;
        
        class_636 interactionManager = client.field_1761;
        if (interactionManager == null) return;
        
        // Aumenta a velocidade de quebra em criativo
        if (client.field_1724 != null && client.field_1724.method_7337()) {
            // A quebra instantânea já é nativa do criativo
        }
    }
    
    @Override
    public void shutdown() {
        System.out.println("⚡ [Nebula] Faster Block Breaking desligado!");
    }
    
    @Override
    public boolean isEnabled() {
        return enabled && NebulaConfig.enableFasterBlockBreaking;
    }
}
