package com.nebula;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2791;

public class NebulaChunkSection {

    private static final ExecutorService BUILD_POOL = Executors.newFixedThreadPool(2);
    
    private final class_2791 chunk;
    private volatile boolean dirty = true;
    private NebulaMesh mesh;
    private long lastBuildTime = 0;

    public NebulaChunkSection(class_2791 chunk) {
        this.chunk = chunk;
    }

    public boolean needsRebuild() {
        return dirty;
    }

    public void rebuildAsync() {
        long now = System.currentTimeMillis();
        if (now - lastBuildTime < 100) return;

        lastBuildTime = now;
        CompletableFuture.runAsync(this::rebuildGreedy, BUILD_POOL);
    }

    private void rebuildGreedy() {
        NebulaMesh newMesh = new NebulaMesh();

        try {
            for (class_2350 dir : class_2350.values()) {
                greedyMeshDirection(newMesh, dir);
            }
        } catch (Exception ignored) {}

        newMesh.finishBuilding();
        this.mesh = newMesh;
        this.dirty = false;
    }

    private void greedyMeshDirection(NebulaMesh mesh, class_2350 dir) {
        boolean[][] mask = new boolean[16][16];

        for (int slice = 0; slice < 16; slice++) {
            for (int u = 0; u < 16; u++) {
                for (int v = 0; v < 16; v++) {
                    class_2338 pos = getPos(dir, slice, u, v);
                    class_2680 state = chunk.method_8320(pos);

                    if (state.method_26215() || !state.method_26225()) {
                        mask[u][v] = false;
                        continue;
                    }

                    class_2338 neighbor = pos.method_10093(dir);
                    class_2680 neighborState = chunk.method_8320(neighbor);
                    mask[u][v] = neighborState.method_26215() || !neighborState.method_26225();
                }
            }

            for (int u = 0; u < 16; u++) {
                for (int v = 0; v < 16; ) {
                    if (!mask[u][v]) {
                        v++;
                        continue;
                    }

                    int width = 1;
                    while (u + width < 16 && mask[u + width][v]) {
                        width++;
                    }

                    int height = 1;
                    boolean done = false;
                    while (v + height < 16 && !done) {
                        for (int k = 0; k < width; k++) {
                            if (!mask[u + k][v + height]) {
                                done = true;
                                break;
                            }
                        }
                        if (!done) height++;
                    }

                    addMergedFace(mesh, dir, slice, u, v, width, height);

                    for (int dx = 0; dx < width; dx++) {
                        for (int dy = 0; dy < height; dy++) {
                            mask[u + dx][v + dy] = false;
                        }
                    }

                    v += height;
                }
            }
        }
    }

    private class_2338 getPos(class_2350 dir, int slice, int u, int v) {
        return switch (dir.method_10166()) {
            case field_11048 -> new class_2338(slice, u, v);
            case field_11052 -> new class_2338(u, slice, v);
            case field_11051 -> new class_2338(u, v, slice);
        };
    }

    private void addMergedFace(NebulaMesh mesh, class_2350 dir, int slice, int u, int v, int width, int height) {
        int color = 0xFFFFFFFF;
        int light = 0x00F000F0;

        float x = u;
        float y = v;
        float w = width;
        float h = height;

        switch (dir) {
            case field_11036 -> mesh.addQuad(x, slice+1, y, x+w, slice+1, y, x+w, slice+1, y+h, x, slice+1, y+h, color, light);
            case field_11033 -> mesh.addQuad(x, slice, y+h, x+w, slice, y+h, x+w, slice, y, x, slice, y, color, light);
            case field_11043 -> mesh.addQuad(x+w, y, slice, x, y, slice, x, y+h, slice, x+w, y+h, slice, color, light);
            case field_11035 -> mesh.addQuad(x, y, slice+1, x+w, y, slice+1, x+w, y+h, slice+1, x, y+h, slice+1, color, light);
            case field_11039 -> mesh.addQuad(slice, y, x+w, slice, y, x, slice, y+h, x, slice, y+h, x+w, color, light);
            case field_11034 -> mesh.addQuad(slice+1, y, x, slice+1, y, x+w, slice+1, y+h, x+w, slice+1, y+h, x, color, light);
        }
    }

    public void render() {
        if (mesh != null) mesh.draw();
    }

    public void markDirty() {
        this.dirty = true;
    }

    public void delete() {
        if (mesh != null) {
            mesh.delete();
            mesh = null;
        }
    }
}
