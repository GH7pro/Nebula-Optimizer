package com.nebula;

import com.nebula.lib.api.BudgetAPI;
import com.nebula.lib.api.CullingAPI;
import com.nebula.lib.api.FocusAPI;
import com.nebula.lib.api.PerformanceAPI;
import com.nebula.lib.api.ProfileAPI;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class NebulaDebug {

    public static int culledEntities = 0;
    public static int totalEntities = 0;
    public static int visibleSections = 0;

    public static void render(class_332 context) {
        if (!NebulaConfig.debugMode) return;

        class_310 client = class_310.method_1551();
        if (client == null || client.field_1772 == null) return;

        class_327 tr = client.field_1772;
        int y = 30;
        int x = 10;

        context.method_51433(tr, "§6§l[Nebula Debug]", x, y, 0xFFFFFF, true);
        y += 12;

        context.method_51433(tr, "§7Profile: §e" + ProfileAPI.getCurrentProfile().getDisplayName(), x, y, 0xFFFFFF, true);
        y += 12;

        context.method_51433(tr, String.format("§7FPS: §a%.1f §8| §7Avg: §a%.1f",
                PerformanceAPI.getCurrentFps(), PerformanceAPI.getAverageFps()), x, y, 0xFFFFFF, true);
        y += 12;

        context.method_51433(tr, "§7Entities: §f" + totalEntities + " §8| §7Culled: §c" + culledEntities, x, y, 0xFFFFFF, true);
        y += 12;

        context.method_51433(tr, "§7Density: §b" + PerformanceAPI.getDensityStatus() +
                " §8(" + String.format("%.2f", CullingAPI.getDensityMultiplier()) + ")", x, y, 0xFFFFFF, true);
        y += 12;

        context.method_51433(tr, "§7Focus: " + (FocusAPI.isFocused() ? "§aON" : "§cOFF") +
                " §8| §7Budget: §f" + BudgetAPI.getRenderedThisFrame() + "/" + BudgetAPI.getMaxEntitiesPerFrame(), x, y, 0xFFFFFF, true);
        y += 12;

        context.method_51433(tr, "§7Culling: " + onOff(CullingAPI.isEntityCullingEnabled()) +
                " §8| §7Angle: " + onOff(CullingAPI.isAngleCullingEnabled()) +
                " §8| §7Aggro: " + onOff(CullingAPI.isAggressiveCullingEnabled()), x, y, 0xFFFFFF, true);
        y += 12;

        context.method_51433(tr, "§7Block Culling: " + onOff(CullingAPI.isBlockCullingEnabled()) +
                " §8| §7Particle Killer: " + onOff(NebulaConfig.enableParticleKiller), x, y, 0xFFFFFF, true);
    }

    private static String onOff(boolean v) {
        return v ? "§aON" : "§cOFF";
    }

    public static void resetCounters() {
        culledEntities = 0;
        totalEntities = 0;
        visibleSections = 0;
    }
}
