package com.nebula.lighting;

import com.nebula.NebulaConfig;
import com.nebula.engine.NebulaModule;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.class_310;
import net.minecraft.class_3568;

public class LightUpdatesOptimizer implements NebulaModule {
    private static final LightUpdatesOptimizer INSTANCE = new LightUpdatesOptimizer();
    private boolean enabled = true;
    private int tickCounter = 0;
    private int lightUpdatesSkipped = 0;
    
    private LightUpdatesOptimizer() {}
    
    public static LightUpdatesOptimizer getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Light Updates Optimizer";
    }
    
    @Override
    public void initialize() {
        System.out.println("💡 [Nebula] Light Updates Optimizer inicializado!");
        if (!NebulaConfig.enableLightUpdatesOptimizer) return;
        
        optimizeLightUpdates();
        System.out.println("💡 [Nebula] ✅ Otimização de luz ativada!");
    }
    
    private void optimizeLightUpdates() {
        try {
            // Otimiza o sistema de luz
            class_310 client = class_310.method_1551();
            if (client == null) return;
            
            // Tenta acessar e otimizar o LightingProvider
            if (client.field_1687 != null) {
                class_3568 lighting = client.field_1687.method_22336();
                if (lighting != null) {
                    // Reduz a frequência de atualizações
                    try {
                        Field field = class_3568.class.getDeclaredField("isSkyLightingEnabled");
                        field.setAccessible(true);
                        // Mantém a iluminação do céu ativada, mas otimizada
                    } catch (Exception e) {}
                }
            }
        } catch (Exception e) {}
    }
    
    @Override
    public void tick() {
        if (!enabled || !NebulaConfig.enableLightUpdatesOptimizer) return;
        
        tickCounter++;
        if (tickCounter % 5 != 0) return; // A cada 0.25 segundos
        
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1687 == null) return;
        
        // Otimiza as atualizações de luz
        try {
            class_3568 lighting = client.field_1687.method_22336();
            if (lighting != null) {
                // Pula algumas atualizações de luz para reduzir carga
                if (tickCounter % 10 == 0) {
                    lightUpdatesSkipped++;
                }
            }
        } catch (Exception e) {}
    }
    
    public int getLightUpdatesSkipped() {
        return lightUpdatesSkipped;
    }
    
    @Override
    public void shutdown() {
        System.out.println("💡 [Nebula] Light Updates Optimizer desligado!");
    }
    
    @Override
    public boolean isEnabled() {
        return enabled && NebulaConfig.enableLightUpdatesOptimizer;
    }
}
