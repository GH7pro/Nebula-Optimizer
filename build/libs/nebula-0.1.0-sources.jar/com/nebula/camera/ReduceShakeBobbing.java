package com.nebula.camera;

import com.nebula.NebulaConfig;
import com.nebula.engine.NebulaModule;
import net.minecraft.class_310;

public class ReduceShakeBobbing implements NebulaModule {
    private static final ReduceShakeBobbing INSTANCE = new ReduceShakeBobbing();
    private boolean enabled = true;
    private boolean originalBobbing = true;
    
    private ReduceShakeBobbing() {}
    
    public static ReduceShakeBobbing getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Reduce Shake & Bobbing";
    }
    
    @Override
    public void initialize() {
        System.out.println("🎯 [Nebula] Reduce Shake & Bobbing inicializado!");
        if (!NebulaConfig.enableReduceShakeBobbing) return;
        
        try {
            class_310 client = class_310.method_1551();
            if (client == null || client.field_1690 == null) return;
            
            originalBobbing = client.field_1690.method_42448().method_41753();
            client.field_1690.method_42448().method_41748(false);
            
            System.out.println("🎯 [Nebula] ✅ Balanço reduzido!");
        } catch (Exception e) {
            System.err.println("🎯 [Nebula] Erro ao reduzir shake: " + e.getMessage());
        }
    }
    
    @Override
    public void tick() {
        if (!enabled || !NebulaConfig.enableReduceShakeBobbing) return;
        
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1690 == null) return;
        
        if (client.field_1690.method_42448().method_41753()) {
            client.field_1690.method_42448().method_41748(false);
        }
    }
    
    @Override
    public void shutdown() {
        class_310 client = class_310.method_1551();
        if (client != null && client.field_1690 != null) {
            client.field_1690.method_42448().method_41748(originalBobbing);
        }
        System.out.println("🎯 [Nebula] Reduce Shake & Bobbing desligado!");
    }
    
    @Override
    public boolean isEnabled() {
        return enabled && NebulaConfig.enableReduceShakeBobbing;
    }
}
