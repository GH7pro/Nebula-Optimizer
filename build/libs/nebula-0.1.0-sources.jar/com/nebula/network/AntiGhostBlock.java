package com.nebula.network;

import com.nebula.NebulaConfig;
import com.nebula.engine.NebulaModule;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_310;

public class AntiGhostBlock implements NebulaModule {
    private static final AntiGhostBlock INSTANCE = new AntiGhostBlock();
    private boolean enabled = true;
    
    // Armazena blocos que estão "pendentes" de confirmação do servidor
    private Map<class_2338, Long> pendingBlocks = new ConcurrentHashMap<>();
    private Map<class_2338, Integer> retryCount = new ConcurrentHashMap<>();
    
    // Tempo máximo para esperar confirmação (em ms)
    private static final long TIMEOUT_MS = 3000;
    private static final int MAX_RETRIES = 5;
    
    private AntiGhostBlock() {}
    
    public static AntiGhostBlock getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Anti-Ghost Block";
    }
    
    @Override
    public void initialize() {
        System.out.println("👻 [Nebula] Anti-Ghost Block inicializado!");
    }
    
    @Override
    public void tick() {
        if (!enabled) return;
        if (!NebulaConfig.get().enableAntiGhostBlock) return;
        
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null || client.field_1687 == null) return;
        
        long currentTime = System.currentTimeMillis();
        
        // Verifica blocos pendentes
        for (Map.Entry<class_2338, Long> entry : pendingBlocks.entrySet()) {
            class_2338 pos = entry.getKey();
            long timestamp = entry.getValue();
            
            // Se passou do tempo limite, reenvia a quebra
            if (currentTime - timestamp > TIMEOUT_MS) {
                retryBreakBlock(client, pos);
            }
        }
        
        // Limpa blocos que já foram processados
        cleanupProcessedBlocks(client);
    }
    
    public void markBlockForBreaking(class_2338 pos) {
        if (!enabled) return;
        
        // Adiciona o bloco à lista de pendentes
        pendingBlocks.put(pos, System.currentTimeMillis());
        retryCount.put(pos, 0);
        
        if (NebulaConfig.get().debugMode) {
            System.out.println("👻 [Nebula] Bloco marcado para quebra: " + pos);
        }
    }
    
    public void confirmBlockBroken(class_2338 pos) {
        if (!enabled) return;
        
        // Bloco foi confirmado pelo servidor
        pendingBlocks.remove(pos);
        retryCount.remove(pos);
        
        if (NebulaConfig.get().debugMode) {
            System.out.println("✅ [Nebula] Bloco confirmado: " + pos);
        }
    }
    
    private void retryBreakBlock(class_310 client, class_2338 pos) {
        int retries = retryCount.getOrDefault(pos, 0);
        
        if (retries >= MAX_RETRIES) {
            // Desiste após muitas tentativas
            pendingBlocks.remove(pos);
            retryCount.remove(pos);
            
            if (NebulaConfig.get().debugMode) {
                System.out.println("❌ [Nebula] Desistindo do bloco: " + pos + " (muitas tentativas)");
            }
            return;
        }
        
        // Reenvia a ação de quebrar
        if (client.field_1761 != null && client.field_1724 != null) {
            retryCount.put(pos, retries + 1);
            pendingBlocks.put(pos, System.currentTimeMillis());
            
            // Tenta quebrar novamente
            client.field_1761.method_2899(pos);
            
            if (NebulaConfig.get().debugMode) {
                System.out.println("🔄 [Nebula] Re-tentando quebrar bloco: " + pos + " (tentativa " + (retries + 1) + ")");
            }
        }
    }
    
    private void cleanupProcessedBlocks(class_310 client) {
        class_1937 world = client.field_1687;
        if (world == null) return;
        
        // Remove blocos que já foram quebrados
        for (class_2338 pos : pendingBlocks.keySet()) {
            if (world.method_8320(pos).method_26215()) {
                confirmBlockBroken(pos);
            }
        }
    }
    
    public boolean isBlockPending(class_2338 pos) {
        return pendingBlocks.containsKey(pos);
    }
    
    public int getPendingCount() {
        return pendingBlocks.size();
    }
    
    public void reset() {
        pendingBlocks.clear();
        retryCount.clear();
    }
    
    @Override
    public void shutdown() {
        reset();
        System.out.println("👻 [Nebula] Anti-Ghost Block desligado!");
    }
    
    @Override
    public boolean isEnabled() {
        return enabled && NebulaConfig.get().enableAntiGhostBlock;
    }
}
