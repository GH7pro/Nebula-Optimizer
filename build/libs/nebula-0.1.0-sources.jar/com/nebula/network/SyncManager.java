package com.nebula.network;

import com.nebula.NebulaConfig;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_310;

public class SyncManager {
    private static final SyncManager INSTANCE = new SyncManager();
    private List<class_2338> blocksToSync = new ArrayList<>();
    private int syncCounter = 0;
    
    private SyncManager() {}
    
    public static SyncManager getInstance() {
        return INSTANCE;
    }
    
    public void tick() {
        if (!NebulaConfig.get().enableAntiGhostBlock) return;
        
        syncCounter++;
        
        // A cada 5 segundos, verifica sincronização
        if (syncCounter % 100 == 0) {
            forceSync();
        }
    }
    
    public void forceSync() {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null || client.field_1687 == null) return;
        
        // Força a sincronização de blocos pendentes
        for (class_2338 pos : blocksToSync) {
            if (client.field_1687.method_8320(pos).method_26215()) {
                blocksToSync.remove(pos);
                AntiGhostBlock.getInstance().confirmBlockBroken(pos);
            }
        }
        
        if (NebulaConfig.get().debugMode) {
            System.out.println("🔄 [Nebula] Sincronização forçada! Blocos pendentes: " + blocksToSync.size());
        }
    }
    
    public void addBlockToSync(class_2338 pos) {
        if (!blocksToSync.contains(pos)) {
            blocksToSync.add(pos);
        }
    }
    
    public void removeBlockFromSync(class_2338 pos) {
        blocksToSync.remove(pos);
    }
}
