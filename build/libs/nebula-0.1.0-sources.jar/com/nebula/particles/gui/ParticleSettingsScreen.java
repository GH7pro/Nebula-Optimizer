package com.nebula.particles.gui;

import com.nebula.particles.ParticleManager;
import java.awt.Color;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7842;

public class ParticleSettingsScreen extends class_437 {
    private final class_437 parent;
    private int scrollOffset = 0;
    private int selectedIndex = -1;
    private ParticleManager manager;
    
    private static final int HEADER_HEIGHT = 50;
    private static final int ITEM_HEIGHT = 30;
    private static final int ITEM_SPACING = 2;
    private static final int MAX_VISIBLE = 12;
    private static final int FOOTER_HEIGHT = 50;
    
    public ParticleSettingsScreen(class_437 parent) {
        super(class_2561.method_43470("Particle Settings"));
        this.parent = parent;
        this.manager = ParticleManager.getInstance();
        this.manager.loadSettings();
    }
    
    @Override
    protected void method_25426() {
        super.method_25426();
        
        int buttonY = field_22790 - 25;
        
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("← Back"),
            button -> {
                if (this.field_22787 != null) {
                    this.field_22787.method_1507(this.parent);
                }
            }
        ).method_46434(10, buttonY, 80, 20).method_46431());
        
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("❌ Disable All"),
            button -> {
                manager.disableAll();
            }
        ).method_46434(field_22789 - 270, buttonY, 100, 20).method_46431());
        
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("✅ Enable All"),
            button -> {
                manager.resetAll();
            }
        ).method_46434(field_22789 - 160, buttonY, 70, 20).method_46431());
        
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("✓ Apply"),
            button -> {
                manager.saveSettings();
                System.out.println("💀 [Nebula] Configurações de partículas aplicadas!");
            }
        ).method_46434(field_22789 - 80, buttonY, 70, 20).method_46431());
        
        this.method_37063(new class_7842(
            20, 12, 300, 22,
            class_2561.method_43470("💀 Particle Settings").method_27695(class_124.field_1065, class_124.field_1067),
            field_22793
        ));
        
        this.method_37063(new class_7842(
            20, 34, 300, 16,
            class_2561.method_43470("Select which particles to remove").method_27692(class_124.field_1080),
            field_22793
        ));
    }
    
    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, field_22789, field_22790, new Color(25, 25, 40, 255).getRGB());
        context.method_25294(0, 0, field_22789, HEADER_HEIGHT, new Color(15, 15, 30, 255).getRGB());
        context.method_25294(0, HEADER_HEIGHT - 1, field_22789, HEADER_HEIGHT, new Color(255, 180, 0, 60).getRGB());
        
        String[] particleTypes = ParticleManager.PARTICLE_TYPES;
        int y = HEADER_HEIGHT + 10;
        int start = scrollOffset;
        int end = Math.min(start + MAX_VISIBLE, particleTypes.length);
        
        for (int i = start; i < end; i++) {
            String type = particleTypes[i];
            boolean enabled = manager.isParticleEnabled(type);
            boolean hover = mouseX > 20 && mouseX < field_22789 - 20 && 
                           mouseY > y && mouseY < y + ITEM_HEIGHT;
            boolean selected = (i == selectedIndex);
            
            if (selected) {
                context.method_25294(20, y, field_22789 - 20, y + ITEM_HEIGHT, new Color(255, 180, 0, 40).getRGB());
            } else if (hover) {
                context.method_25294(20, y, field_22789 - 20, y + ITEM_HEIGHT, new Color(255, 255, 255, 10).getRGB());
            }
            
            context.method_49601(20, y, field_22789 - 40, ITEM_HEIGHT, new Color(60, 60, 80, 80).getRGB());
            
            String displayName = formatParticleName(type);
            context.method_51433(field_22793, displayName, 35, y + 9, 0xDDDDDD, false);
            
            String status = enabled ? "✅ ON" : "❌ OFF";
            int color = enabled ? 0x55FF55 : 0xFF5555;
            context.method_51433(field_22793, status, field_22789 - 60, y + 9, color, false);
            
            y += ITEM_HEIGHT + ITEM_SPACING;
        }
        
        if (ParticleManager.PARTICLE_TYPES.length > MAX_VISIBLE) {
            context.method_51433(field_22793, 
                "▼ " + (ParticleManager.PARTICLE_TYPES.length - MAX_VISIBLE) + " more (scroll)", 
                20, y + 10, 
                0x555555, false);
        }
        
        int footerY = field_22790 - FOOTER_HEIGHT;
        context.method_25294(0, footerY, field_22789, field_22790, new Color(15, 15, 30, 255).getRGB());
        context.method_25294(0, footerY - 1, field_22789, footerY, new Color(255, 180, 0, 20).getRGB());
        
        int total = ParticleManager.PARTICLE_TYPES.length;
        int enabledCount = 0;
        for (String type : ParticleManager.PARTICLE_TYPES) {
            if (manager.isParticleEnabled(type)) enabledCount++;
        }
        
        context.method_51433(field_22793, 
            "📊 " + enabledCount + "/" + total + " partículas ativas", 
            20, footerY + 16, 
            0x888888, false);
        context.method_51433(field_22793, 
            "💡 Click to toggle | Scroll to see more", 
            20, footerY + 34, 
            0x444444, false);
        
        super.method_25394(context, mouseX, mouseY, delta);
    }
    
    private String formatParticleName(String type) {
        String[] parts = type.toLowerCase().split("_");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (sb.length() > 0) sb.append(" ");
            sb.append(Character.toUpperCase(part.charAt(0)));
            sb.append(part.substring(1));
        }
        return sb.toString();
    }
    
    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        int y = HEADER_HEIGHT + 10;
        int start = scrollOffset;
        int end = Math.min(start + MAX_VISIBLE, ParticleManager.PARTICLE_TYPES.length);
        
        for (int i = start; i < end; i++) {
            if (mouseX > 20 && mouseX < field_22789 - 20 && 
                mouseY > y && mouseY < y + ITEM_HEIGHT) {
                selectedIndex = i;
                String type = ParticleManager.PARTICLE_TYPES[i];
                boolean current = manager.isParticleEnabled(type);
                manager.setParticleEnabled(type, !current);
                return true;
            }
            y += ITEM_HEIGHT + ITEM_SPACING;
        }
        
        return super.method_25402(mouseX, mouseY, button);
    }
    
    @Override
    public boolean method_25401(double mouseX, double mouseY, double amount) {
        int maxScroll = Math.max(0, ParticleManager.PARTICLE_TYPES.length - MAX_VISIBLE);
        scrollOffset = (int) Math.max(0, Math.min(scrollOffset - amount, maxScroll));
        return true;
    }
    
    @Override
    public boolean method_25421() {
        return false;
    }
}
