package com.nebula.afk;

import com.nebula.NebulaConfig;
import com.nebula.engine.NebulaModule;
import net.minecraft.class_243;
import net.minecraft.class_310;

public class AFKDetector implements NebulaModule {
    private static final AFKDetector INSTANCE = new AFKDetector();
    private boolean enabled = true;
    private class_243 lastPosition = class_243.field_1353;
    private int stationaryTicks = 0;
    private boolean isAFK = false;
    private int afkTickCounter = 0;
    
    private static final int AFK_THRESHOLD = 1200; // 60 segundos parado
    private static final int CHECK_INTERVAL = 20;  // A cada 1 segundo
    
    private AFKDetector() {}
    
    public static AFKDetector getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Smart AFK Detection";
    }
    
    @Override
    public void initialize() {
        System.out.println("💤 [Nebula] Smart AFK Detection inicializado!");
    }
    
    @Override
    public void tick() {
        if (!enabled || !NebulaConfig.enableAFKDetection) return;
        
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null) return;
        
        afkTickCounter++;
        if (afkTickCounter % CHECK_INTERVAL != 0) return;
        
        class_243 currentPos = client.field_1724.method_19538();
        
        if (currentPos.method_1022(lastPosition) < 0.01) {
            stationaryTicks++;
        } else {
            stationaryTicks = 0;
            if (isAFK) {
                exitAFKMode(client);
            }
        }
        
        lastPosition = currentPos;
        
        if (stationaryTicks > AFK_THRESHOLD && !isAFK) {
            enterAFKMode(client);
        }
    }
    
    private void enterAFKMode(class_310 client) {
        isAFK = true;
        System.out.println("💤 [Nebula] Jogador AFK detectado! Ativando modo economia...");
        
        // Reduz drasticamente o consumo
        client.field_1690.method_42524().method_41748(10);
//         client.options.getViewDistance().setValue(4);
        client.field_1690.method_42534().method_41748(net.minecraft.class_5365.field_25427);
        client.field_1690.method_42475().method_41748(net.minecraft.class_4066.field_18199);
        
    }
    
    private void exitAFKMode(class_310 client) {
        isAFK = false;
        System.out.println("💤 [Nebula] Jogador voltou! Restaurando configurações...");
        
        // Restaura configurações
        client.field_1690.method_42524().method_41748(60);
//         client.options.getViewDistance().setValue(12);
        client.field_1690.method_42534().method_41748(net.minecraft.class_5365.field_25428);
        client.field_1690.method_42475().method_41748(net.minecraft.class_4066.field_18197);
    }
    
    public boolean isAFK() {
        return isAFK;
    }
    
    @Override
    public void shutdown() {
        System.out.println("💤 [Nebula] Smart AFK Detection desligado!");
    }
    
    @Override
    public boolean isEnabled() {
        return enabled && NebulaConfig.enableAFKDetection;
    }
}
