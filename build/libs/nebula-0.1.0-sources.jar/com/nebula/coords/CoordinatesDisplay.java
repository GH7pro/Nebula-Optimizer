package com.nebula.coords;

import com.nebula.NebulaConfig;
import com.nebula.engine.NebulaModule;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;

public class CoordinatesDisplay implements NebulaModule {
    private static final CoordinatesDisplay INSTANCE = new CoordinatesDisplay();
    private boolean enabled = true;
    private boolean showCoords = true;
    
    private CoordinatesDisplay() {}
    
    public static CoordinatesDisplay getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Coordinates Display";
    }
    
    @Override
    public void initialize() {
        System.out.println("📍 [Nebula] Coordinates Display inicializado!");
        if (!NebulaConfig.enableCoordinatesDisplay) return;
        
        System.out.println("📍 [Nebula] ✅ Coordenadas ativadas!");
    }
    
    @Override
    public void tick() {
        // Não faz nada no tick, só renderiza
    }
    
    public void render(class_332 context, class_310 client) {
        if (!enabled || !NebulaConfig.enableCoordinatesDisplay) return;
        if (!showCoords) return;
        if (client == null || client.field_1724 == null) return;
        
        class_327 renderer = client.field_1772;
        class_2338 pos = client.field_1724.method_24515();
        
        // Obtém as coordenadas
        int x = pos.method_10263();
        int y = pos.method_10264();
        int z = pos.method_10260();
        
        // Obtém a direção
        String direction = getDirection(client.field_1724.method_36454());
        
        // Formata o texto
        String coordsText = String.format("📍 %d %d %d  %s", x, y, z, direction);
        
        // Posição na tela (canto superior esquerdo)
        int xPos = 10;
        int yPos = 10;
        
        // Desenha o fundo
        int width = renderer.method_1727(coordsText) + 10;
        context.method_25294(xPos - 5, yPos - 2, xPos + width, yPos + 12, 0x80000000);
        
        // Desenha o texto
        context.method_51439(renderer, class_2561.method_43470(coordsText), xPos, yPos, 0xFFFFFF, true);
    }
    
    private String getDirection(float yaw) {
        yaw = class_3532.method_15393(yaw);
        if (yaw < -135 || yaw >= 135) return "N";
        if (yaw >= -135 && yaw < -45) return "E";
        if (yaw >= -45 && yaw < 45) return "S";
        if (yaw >= 45 && yaw < 135) return "W";
        return "?";
    }
    
    public void toggle() {
        showCoords = !showCoords;
    }
    
    public boolean isShowing() {
        return showCoords;
    }
    
    @Override
    public void shutdown() {
        System.out.println("📍 [Nebula] Coordinates Display desligado!");
    }
    
    @Override
    public boolean isEnabled() {
        return enabled && NebulaConfig.enableCoordinatesDisplay;
    }
}
