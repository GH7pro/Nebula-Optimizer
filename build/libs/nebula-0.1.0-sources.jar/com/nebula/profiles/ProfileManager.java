package com.nebula.profiles;

import com.nebula.NebulaConfig;
import net.minecraft.class_310;
import net.minecraft.class_4066;
import net.minecraft.class_5365;

public class ProfileManager {
    private static final ProfileManager INSTANCE = new ProfileManager();
    private DeviceDetector.DeviceType currentProfile = DeviceDetector.DeviceType.UNKNOWN;
    private boolean applied = false;
    
    private ProfileManager() {}
    
    public static ProfileManager getInstance() {
        return INSTANCE;
    }
    
    public void initialize() {
        System.out.println("📱 [Nebula] Profile Manager inicializado!");
        
        if (!NebulaConfig.enableAutoProfile) {
            System.out.println("📱 [Nebula] ⚠️ Auto-Profile desativado!");
            return;
        }
        
        DeviceDetector detector = DeviceDetector.getInstance();
        currentProfile = detector.getDeviceType();
        
        System.out.println("📱 [Nebula] Perfil detectado: " + currentProfile.getDisplayName());
        
        // Aplica o perfil no próximo tick (depois do jogo iniciar)
        applyProfileDelayed();
    }
    
    private void applyProfileDelayed() {
        // Espera o jogo inicializar completamente
        new Thread(() -> {
            try {
                Thread.sleep(1000); // Espera 1 segundo
            } catch (InterruptedException e) {}
            
            class_310 client = class_310.method_1551();
            if (client != null) {
                applyProfile();
            }
        }).start();
    }
    
    public void applyProfile() {
        if (!NebulaConfig.enableAutoProfile) return;
        if (applied) return;
        
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1690 == null) {
            // Tenta novamente depois
            applyProfileDelayed();
            return;
        }
        
        System.out.println("📱 [Nebula] Aplicando perfil: " + currentProfile.getDisplayName());
        
        switch (currentProfile) {
            case GAMING_PC:
                applyGamingProfile(client);
                break;
            case DESKTOP:
                applyDesktopProfile(client);
                break;
            case LAPTOP:
                applyLaptopProfile(client);
                break;
            case MOBILE:
                applyMobileProfile(client);
                break;
            case LOW_END:
                applyLowEndProfile(client);
                break;
            default:
                applyDefaultProfile(client);
                break;
        }
        
        applied = true;
        System.out.println("📱 [Nebula] ✅ Perfil aplicado com sucesso!");
    }
    
    private void applyGamingProfile(class_310 client) {
        System.out.println("📱 [Nebula] 🎮 Perfil GAMING PC:");
        System.out.println("📱 [Nebula]   - Qualidade máxima");
        System.out.println("📱 [Nebula]   - FPS: 120");
        System.out.println("📱 [Nebula]   - Render Distance: 16");
        
//         client.options.getViewDistance().setValue(16);
//         client.options.getSimulationDistance().setValue(12);
        client.field_1690.method_42534().method_41748(class_5365.field_25429);
        client.field_1690.method_42475().method_41748(class_4066.field_18197);
        client.field_1690.method_42524().method_41748(120);
        client.field_1690.method_42435().method_41748(true);
    }
    
    private void applyDesktopProfile(class_310 client) {
        System.out.println("📱 [Nebula] 🖥️ Perfil DESKTOP:");
        System.out.println("📱 [Nebula]   - Qualidade alta");
        System.out.println("📱 [Nebula]   - FPS: 60");
        System.out.println("📱 [Nebula]   - Render Distance: 12");
        
//         client.options.getViewDistance().setValue(12);
//         client.options.getSimulationDistance().setValue(10);
        client.field_1690.method_42534().method_41748(class_5365.field_25428);
        client.field_1690.method_42475().method_41748(class_4066.field_18197);
        client.field_1690.method_42524().method_41748(60);
        client.field_1690.method_42435().method_41748(true);
    }
    
    private void applyLaptopProfile(class_310 client) {
        System.out.println("📱 [Nebula] 💻 Perfil LAPTOP:");
        System.out.println("📱 [Nebula]   - Qualidade média");
        System.out.println("📱 [Nebula]   - FPS: 45");
        System.out.println("📱 [Nebula]   - Render Distance: 10");
        
//         client.options.getViewDistance().setValue(10);
//         client.options.getSimulationDistance().setValue(8);
        client.field_1690.method_42534().method_41748(class_5365.field_25428);
        client.field_1690.method_42475().method_41748(class_4066.field_18198);
        client.field_1690.method_42524().method_41748(45);
        client.field_1690.method_42435().method_41748(true);
    }
    
    private void applyMobileProfile(class_310 client) {
        System.out.println("📱 [Nebula] 📱 Perfil MOBILE:");
        System.out.println("📱 [Nebula]   - Qualidade baixa");
        System.out.println("📱 [Nebula]   - FPS: 30");
        System.out.println("📱 [Nebula]   - Render Distance: 6");
        
//         client.options.getViewDistance().setValue(6);
//         client.options.getSimulationDistance().setValue(4);
        client.field_1690.method_42534().method_41748(class_5365.field_25427);
        client.field_1690.method_42475().method_41748(class_4066.field_18199);
        client.field_1690.method_42524().method_41748(30);
        client.field_1690.method_42435().method_41748(false);
    }
    
    private void applyLowEndProfile(class_310 client) {
        System.out.println("📱 [Nebula] ⚠️ Perfil LOW END:");
        System.out.println("📱 [Nebula]   - Qualidade mínima");
        System.out.println("📱 [Nebula]   - FPS: 20");
        System.out.println("📱 [Nebula]   - Render Distance: 4");
        
//         client.options.getViewDistance().setValue(4);
//         client.options.getSimulationDistance().setValue(4);
        client.field_1690.method_42534().method_41748(class_5365.field_25427);
        client.field_1690.method_42475().method_41748(class_4066.field_18199);
        client.field_1690.method_42524().method_41748(20);
        client.field_1690.method_42435().method_41748(false);
    }
    
    private void applyDefaultProfile(class_310 client) {
        System.out.println("📱 [Nebula] Perfil DEFAULT:");
        System.out.println("📱 [Nebula]   - Configurações padrão");
        
//         client.options.getViewDistance().setValue(12);
//         client.options.getSimulationDistance().setValue(8);
        client.field_1690.method_42534().method_41748(class_5365.field_25428);
        client.field_1690.method_42475().method_41748(class_4066.field_18197);
        client.field_1690.method_42524().method_41748(60);
        client.field_1690.method_42435().method_41748(true);
    }
    
    public DeviceDetector.DeviceType getCurrentProfile() {
        return currentProfile;
    }
    
    public void reset() {
        applied = false;
    }
}
