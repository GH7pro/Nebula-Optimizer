package com.nebula.logic;

import com.nebula.NebulaConfig;
import com.nebula.engine.NebulaModule;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1657;
import net.minecraft.class_310;

public class LogicOptimizer implements NebulaModule {
    private static final LogicOptimizer INSTANCE = new LogicOptimizer();
    private boolean enabled = true;
    private int tickCounter = 0;
    
    private LogicOptimizer() {}
    
    public static LogicOptimizer getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Logic Optimizer";
    }
    
    @Override
    public void initialize() {
        System.out.println("🧠 [Nebula] Logic Optimizer inicializado!");
        if (!NebulaConfig.enableLogicOptimization) return;
        
        System.out.println("🧠 [Nebula] ✅ Otimização da lógica ativada!");
    }
    
    @Override
    public void tick() {
        if (!enabled || !NebulaConfig.enableLogicOptimization) return;
        
        tickCounter++;
        if (tickCounter % 20 != 0) return;
        
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null || client.field_1687 == null) return;
        
        optimizeMobAI(client);
    }
    
    private void optimizeMobAI(class_310 client) {
        class_1657 player = client.field_1724;
        if (player == null) return;
        
        // Converte Iterable para List
        List<class_1297> entities = new ArrayList<>();
        for (class_1297 entity : client.field_1687.method_18112()) {
            entities.add(entity);
        }
        
        int mobCount = 0;
        
        for (class_1297 entity : entities) {
            if (entity == player) continue;
            if (entity instanceof class_1308) {
                mobCount++;
                double distance = player.method_5739(entity);
                
                if (distance > 50) {
                    try {
                        ((class_1308) entity).method_5977(true);
                    } catch (Exception e) {}
                } else if (distance > 30) {
                    if (tickCounter % 2 == 0) {
                        try {
                            ((class_1308) entity).method_5977(false);
                        } catch (Exception e) {}
                    } else {
                        try {
                            ((class_1308) entity).method_5977(true);
                        } catch (Exception e) {}
                    }
                } else {
                    try {
                        ((class_1308) entity).method_5977(false);
                    } catch (Exception e) {}
                }
            }
        }
        
        if (NebulaConfig.debugMode && mobCount > 20 && tickCounter % 100 == 0) {
            System.out.println("🧠 [Nebula] Mobs ativos: " + mobCount);
        }
    }
    
    @Override
    public void shutdown() {
        System.out.println("🧠 [Nebula] Logic Optimizer desligado!");
    }
    
    @Override
    public boolean isEnabled() {
        return enabled && NebulaConfig.enableLogicOptimization;
    }
}
