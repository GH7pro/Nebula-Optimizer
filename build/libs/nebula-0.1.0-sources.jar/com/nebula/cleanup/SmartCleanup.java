package com.nebula.cleanup;

import com.nebula.NebulaConfig;
import com.nebula.engine.NebulaModule;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_310;

public class SmartCleanup implements NebulaModule {
    private static final SmartCleanup INSTANCE = new SmartCleanup();
    private boolean enabled = true;
    private int tickCounter = 0;
    private ConcurrentHashMap<UUID, Integer> entityAge = new ConcurrentHashMap<>();
    private int cleanedCount = 0;
    
    // Configurações
    private static final int MAX_ITEMS = 50;
    private static final int ITEM_LIFETIME = 600; // 30 segundos
    private static final int MOB_STUCK_TIMEOUT = 1200; // 60 segundos
    private static final int MAX_MOBS = 80;
    private static final int MAX_ENTITIES = 200;
    
    private SmartCleanup() {}
    
    public static SmartCleanup getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Smart Cleanup";
    }
    
    @Override
    public void initialize() {
        System.out.println("🧹 [Nebula] Smart Cleanup inicializado!");
        if (!NebulaConfig.enableSmartCleanupAdvanced) return;
        
        System.out.println("🧹 [Nebula] ✅ Limpeza inteligente ativada!");
    }
    
    @Override
    public void tick() {
        if (!enabled || !NebulaConfig.enableSmartCleanupAdvanced) return;
        
        tickCounter++;
        if (tickCounter % 100 != 0) return; // A cada 5 segundos
        
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null || client.field_1687 == null) return;
        
        class_1657 player = client.field_1724;
        List<class_1297> toRemove = new ArrayList<>();
        int itemCount = 0;
        int mobCount = 0;
        int totalEntities = 0;
        
        for (class_1297 entity : client.field_1687.method_18112()) {
            if (entity == player) continue;
            
            totalEntities++;
            UUID id = entity.method_5667();
            int age = entityAge.getOrDefault(id, 0) + 1;
            entityAge.put(id, age);
            double distance = player.method_5739(entity);
            
            // ===== 1. LIMPEZA DE ITENS =====
            if (entity instanceof class_1542) {
                itemCount++;
                if (itemCount > MAX_ITEMS || age > ITEM_LIFETIME) {
                    toRemove.add(entity);
                }
            }
            
            // ===== 2. LIMPEZA DE MOBS PRESOS =====
            if (entity instanceof class_1308) {
                mobCount++;
                if (mobCount > MAX_MOBS) {
                    toRemove.add(entity);
                } else if (age > MOB_STUCK_TIMEOUT && distance > 20) {
                    toRemove.add(entity);
                }
            }
            
            // ===== 3. LIMPEZA GERAL =====
            if (totalEntities > MAX_ENTITIES && distance > 30) {
                toRemove.add(entity);
            }
        }
        
        // ===== REMOVE ENTIDADES =====
        for (class_1297 entity : toRemove) {
            try {
                entity.method_5650(class_1297.class_5529.field_26999);
                cleanedCount++;
                entityAge.remove(entity.method_5667());
            } catch (Exception e) {}
        }
        
        if (NebulaConfig.debugMode && cleanedCount > 0 && tickCounter % 500 == 0) {
            System.out.println("🧹 [Nebula] Limpeza: " + cleanedCount + " entidades removidas");
            System.out.println("🧹 [Nebula] 📊 Itens: " + itemCount + "/" + MAX_ITEMS + " | Mobs: " + mobCount + "/" + MAX_MOBS);
        }
    }
    
    public int getCleanedCount() {
        return cleanedCount;
    }
    
    public void resetStats() {
        cleanedCount = 0;
    }
    
    @Override
    public void shutdown() {
        entityAge.clear();
        System.out.println("🧹 [Nebula] Smart Cleanup desligado!");
    }
    
    @Override
    public boolean isEnabled() {
        return enabled && NebulaConfig.enableSmartCleanupAdvanced;
    }
}
