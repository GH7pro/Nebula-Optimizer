package com.nebula.chunk;

import com.nebula.NebulaConfig;
import com.nebula.engine.NebulaModule;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;

public class ChunkLoaderOptimizer implements NebulaModule {
    private static final ChunkLoaderOptimizer INSTANCE = new ChunkLoaderOptimizer();
    private boolean enabled = true;
    private int tickCounter = 0;
    private List<class_2338> pendingChunks = new ArrayList<>();
    private class_2338 lastPlayerPos = null;
    private class_243 lastVelocity = class_243.field_1353;
    
    private static final int CHECK_INTERVAL = 10;
    private static final int PRELOAD_DISTANCE = 32;
    
    private ChunkLoaderOptimizer() {}
    
    public static ChunkLoaderOptimizer getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Chunk Loader Optimizer";
    }
    
    @Override
    public void initialize() {
        System.out.println("🗺️ [Nebula] Chunk Loader Optimizer inicializado!");
        if (!NebulaConfig.enableChunkLoaderOptimizer) return;
        
        System.out.println("🗺️ [Nebula] ✅ Carregamento de chunks otimizado!");
    }
    
    @Override
    public void tick() {
        if (!enabled || !NebulaConfig.enableChunkLoaderOptimizer) return;
        
        tickCounter++;
        if (tickCounter % CHECK_INTERVAL != 0) return;
        
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null || client.field_1687 == null) return;
        
        // ===== 1. CARREGAMENTO PREDITIVO =====
        predictiveLoading(client);
        
        // ===== 2. PRIORIDADE DE CHUNKS =====
        prioritizeChunks(client);
        
        // ===== 3. CARREGAMENTO ASSÍNCRONO =====
        asyncChunkLoading(client);
    }
    
    private void predictiveLoading(class_310 client) {
        class_2338 playerPos = client.field_1724.method_24515();
        class_243 velocity = client.field_1724.method_18798();
        
        // Detecta direção do movimento
        if (velocity.method_1033() > 0.1) {
            // Calcula chunks na direção do movimento
            int dx = (int) (velocity.field_1352 * 2);
            int dz = (int) (velocity.field_1350 * 2);
            
            int chunkX = playerPos.method_10263() >> 4;
            int chunkZ = playerPos.method_10260() >> 4;
            
            // Pré-carrega chunks na direção do movimento
            for (int i = 1; i <= 4; i++) {
                int cx = chunkX + dx * i;
                int cz = chunkZ + dz * i;
                
                if (!client.field_1687.method_8393(cx, cz)) {
                    // Inicia carregamento assíncrono
                    final int finalCx = cx;
                    final int finalCz = cz;
                    CompletableFuture.runAsync(() -> {
                        try {
                            client.field_1687.method_2935().method_12246(finalCx, finalCz);
                        } catch (Exception e) {}
                    });
                }
            }
            
            if (NebulaConfig.debugMode && tickCounter % 100 == 0) {
                System.out.println("🗺️ [Nebula] Pré-carregando chunks na direção: " + velocity);
            }
        }
    }
    
    private void prioritizeChunks(class_310 client) {
        // Prioriza chunks que o jogador está olhando
        // (já implementado no DynamicChunkLoader)
    }
    
    private void asyncChunkLoading(class_310 client) {
        // Carrega chunks em background para evitar engasgos
        if (pendingChunks.isEmpty()) return;
        
        // Processa chunks pendentes
        List<class_2338> toProcess = new ArrayList<>(pendingChunks);
        pendingChunks.clear();
        
        for (class_2338 pos : toProcess) {
            int cx = pos.method_10263() >> 4;
            int cz = pos.method_10260() >> 4;
            
            if (!client.field_1687.method_8393(cx, cz)) {
                try {
                    client.field_1687.method_2935().method_12246(cx, cz);
                } catch (Exception e) {}
            }
        }
    }
    
    public void requestChunkLoad(class_2338 pos) {
        if (!pendingChunks.contains(pos)) {
            pendingChunks.add(pos);
        }
    }
    
    @Override
    public void shutdown() {
        pendingChunks.clear();
        System.out.println("🗺️ [Nebula] Chunk Loader Optimizer desligado!");
    }
    
    @Override
    public boolean isEnabled() {
        return enabled && NebulaConfig.enableChunkLoaderOptimizer;
    }
}
