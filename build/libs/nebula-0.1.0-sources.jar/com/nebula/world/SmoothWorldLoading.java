package com.nebula.world;

import com.nebula.NebulaConfig;
import com.nebula.engine.NebulaModule;
import java.lang.reflect.Field;
import net.minecraft.class_310;
import net.minecraft.class_761;

public class SmoothWorldLoading implements NebulaModule {
    private static final SmoothWorldLoading INSTANCE = new SmoothWorldLoading();
    private boolean enabled = true;
    private int tickCounter = 0;
    private boolean isSmooth = false;
    private int loadedChunks = 0;
    
    private SmoothWorldLoading() {}
    
    public static SmoothWorldLoading getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Smooth World Loading";
    }
    
    @Override
    public void initialize() {
        System.out.println("🗺️ [Nebula] Smooth World Loading inicializado!");
        if (!NebulaConfig.enableSmoothWorldLoading) return;
        
        try {
            optimizeWorldLoading();
            isSmooth = true;
            System.out.println("🗺️ [Nebula] ✅ Carregamento suave ativado!");
        } catch (Exception e) {
            System.err.println("🗺️ [Nebula] Erro ao ativar: " + e.getMessage());
        }
    }
    
    private void optimizeWorldLoading() {
        try {
            // Otimiza o carregamento do mundo
            class_310 client = class_310.method_1551();
            if (client == null) return;
            
            // Tenta reduzir o lag ao carregar chunks
            try {
                Field field = class_761.class.getDeclaredField("chunkBuilder");
                field.setAccessible(true);
                Object chunkBuilder = field.get(client.field_1769);
                if (chunkBuilder != null) {
                    // Ajusta o builder para carregar mais suavemente
                    Class<?> builderClass = chunkBuilder.getClass();
                    try {
                        Field threadPool = builderClass.getDeclaredField("threadPool");
                        threadPool.setAccessible(true);
                        // Ajusta o pool de threads
                    } catch (Exception e) {}
                }
            } catch (Exception e) {}
            
        } catch (Exception e) {}
    }
    
    @Override
    public void tick() {
        if (!enabled || !NebulaConfig.enableSmoothWorldLoading) return;
        if (!isSmooth) return;
        
        tickCounter++;
        if (tickCounter % 40 != 0) return;
        
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1687 == null) return;
        
        // Monitora o carregamento de chunks
        int currentLoaded = client.field_1687.method_2935().method_14151();
        if (currentLoaded != loadedChunks) {
            loadedChunks = currentLoaded;
        }
        
        // Se estiver carregando muitos chunks, reduz a prioridade
        if (loadedChunks > 1000 && NebulaConfig.debugMode) {
            System.out.println("🗺️ [Nebula] Chunks carregados: " + loadedChunks);
        }
    }
    
    public int getLoadedChunks() {
        return loadedChunks;
    }
    
    @Override
    public void shutdown() {
        System.out.println("🗺️ [Nebula] Smooth World Loading desligado!");
    }
    
    @Override
    public boolean isEnabled() {
        return enabled && NebulaConfig.enableSmoothWorldLoading;
    }
}
