package com.nebula.entity;

import com.nebula.NebulaConfig;
import com.nebula.engine.NebulaModule;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_310;

public class EntityCleanup implements NebulaModule {
    private static final EntityCleanup INSTANCE = new EntityCleanup();
    private boolean enabled = true;
    private int tickCounter = 0;
    private Map<UUID, Integer> entityAge = new HashMap<>();
    private int cleanedEntities = 0;
    
    private static final int ITEM_LIFETIME = 300; // 15 segundos
    private static final int MOB_STUCK_TIMEOUT = 600; // 30 segundos
    private static final int MAX_ITEMS = 100;
    
    private EntityCleanup() {}
    
    public static EntityCleanup getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Entity Cleanup";
    }
    
    @Override
    public void initialize() {
        System.out.println("🧹 [Nebula] Entity Cleanup inicializado!");
        if (!NebulaConfig.enableEntityCleanup) return;
        
        System.out.println("🧹 [Nebula] ✅ Limpeza de entidades ativada!");
    }
    
    @Override
    public void tick() {
        if (!enabled || !NebulaConfig.enableEntityCleanup) return;
        
        tickCounter++;
        if (tickCounter % 100 != 0) return; // A cada 5 segundos
        
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null || client.field_1687 == null) return;
        
        class_1657 player = client.field_1724;
        List<class_1297> toRemove = new ArrayList<>();
        int itemCount = 0;
        
        for (class_1297 entity : client.field_1687.method_18112()) {
            if (entity == player) continue;
            
            UUID id = entity.method_5667();
            int age = entityAge.getOrDefault(id, 0) + 1;
            entityAge.put(id, age);
            
            // ===== LIMPEZA DE ITENS =====
            if (entity instanceof class_1542) {
                itemCount++;
                double distance = player.method_5739(entity);
                
                // Itens muito distantes ou velhos
                if (distance > 30 || age > ITEM_LIFETIME) {
                    toRemove.add(entity);
                }
            }
            
            // ===== LIMPEZA DE MOBS PRESOS =====
            if (entity instanceof class_1308) {
                double distance = player.method_5739(entity);
                
                // Mobs presos (parados por muito tempo)
                if (age > MOB_STUCK_TIMEOUT && distance > 20) {
                    toRemove.add(entity);
                }
            }
        }
        
        // ===== REMOVE ENTIDADES =====
        for (class_1297 entity : toRemove) {
            try {
                entity.method_5650(class_1297.class_5529.field_26999);
                cleanedEntities++;
                entityAge.remove(entity.method_5667());
            } catch (Exception e) {}
        }
        
        // ===== LIMPEZA DE ITENS EXCESSIVOS =====
        if (itemCount > MAX_ITEMS) {
            // Remove itens extras
            for (class_1297 entity : client.field_1687.method_18112()) {
                if (entity instanceof class_1542 && !toRemove.contains(entity)) {
                    if (itemCount <= MAX_ITEMS) break;
                    try {
                        entity.method_5650(class_1297.class_5529.field_26999);
                        cleanedEntities++;
                        itemCount--;
                    } catch (Exception e) {}
                }
            }
        }
        
        if (NebulaConfig.debugMode && cleanedEntities > 0 && tickCounter % 200 == 0) {
            System.out.println("🧹 [Nebula] Entidades limpas: " + cleanedEntities);
        }
    }
    
    public int getCleanedEntities() {
        return cleanedEntities;
    }
    
    @Override
    public void shutdown() {
        entityAge.clear();
        System.out.println("🧹 [Nebula] Entity Cleanup desligado!");
    }
    
    @Override
    public boolean isEnabled() {
        return enabled && NebulaConfig.enableEntityCleanup;
    }
}
