package com.nebula.entity;

import com.nebula.NebulaConfig;
import com.nebula.engine.NebulaModule;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1657;
import net.minecraft.class_310;

public class ReducedCollisions implements NebulaModule {
    private static final ReducedCollisions INSTANCE = new ReducedCollisions();
    private boolean enabled = true;
    private int tickCounter = 0;
    private int collisionsReduced = 0;
    
    private ReducedCollisions() {}
    
    public static ReducedCollisions getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Reduced Collisions";
    }
    
    @Override
    public void initialize() {
        System.out.println("🎯 [Nebula] Reduced Collisions inicializado!");
        if (!NebulaConfig.enableReducedCollisions) return;
        
        System.out.println("🎯 [Nebula] ✅ Colisões reduzidas ativadas!");
    }
    
    @Override
    public void tick() {
        if (!enabled || !NebulaConfig.enableReducedCollisions) return;
        
        tickCounter++;
        if (tickCounter % 20 != 0) return;
        
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null || client.field_1687 == null) return;
        
        class_1657 player = client.field_1724;
        List<class_1297> entities = new ArrayList<>();
        
        for (class_1297 entity : client.field_1687.method_18112()) {
            entities.add(entity);
        }
        
        for (class_1297 entity : entities) {
            if (entity == player) continue;
            if (entity instanceof class_1308) {
                double distance = player.method_5739(entity);
                
                // Reduz colisões para entidades distantes
                if (distance > 20) {
                    try {
                        // Reduz a sensibilidade de colisão
                        entity.method_5875(true);
                    } catch (Exception e) {}
                } else if (distance > 10) {
                    try {
                        entity.method_5875(false);
                    } catch (Exception e) {}
                }
            }
        }
    }
    
    @Override
    public void shutdown() {
        System.out.println("🎯 [Nebula] Reduced Collisions desligado!");
    }
    
    @Override
    public boolean isEnabled() {
        return enabled && NebulaConfig.enableReducedCollisions;
    }
}
