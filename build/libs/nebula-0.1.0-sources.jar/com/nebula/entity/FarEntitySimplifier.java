package com.nebula.entity;

import com.nebula.NebulaConfig;
import com.nebula.engine.NebulaModule;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1657;
import net.minecraft.class_310;

public class FarEntitySimplifier implements NebulaModule {
    private static final FarEntitySimplifier INSTANCE = new FarEntitySimplifier();
    private boolean enabled = true;
    private int tickCounter = 0;
    private Map<UUID, Integer> entityLOD = new HashMap<>();
    
    private static final int LOD_FULL = 2;
    private static final int LOD_SIMPLE = 1;
    private static final int LOD_MINIMAL = 0;
    
    private FarEntitySimplifier() {}
    
    public static FarEntitySimplifier getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Far Entity Simplifier";
    }
    
    @Override
    public void initialize() {
        System.out.println("📡 [Nebula] Far Entity Simplifier inicializado!");
        if (!NebulaConfig.enableFarEntitySimplifier) return;
        
        System.out.println("📡 [Nebula] ✅ Simplificação de entidades ativada!");
    }
    
    @Override
    public void tick() {
        if (!enabled || !NebulaConfig.enableFarEntitySimplifier) return;
        
        tickCounter++;
        if (tickCounter % 20 != 0) return;
        
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null || client.field_1687 == null) return;
        
        class_1657 player = client.field_1724;
        
        for (class_1297 entity : client.field_1687.method_18112()) {
            if (entity == player) continue;
            if (entity instanceof class_1308) {
                double distance = player.method_5739(entity);
                UUID id = entity.method_5667();
                int newLOD = calculateLOD(distance);
                int currentLOD = entityLOD.getOrDefault(id, LOD_FULL);
                
                if (newLOD != currentLOD) {
                    applyLOD(entity, newLOD);
                    entityLOD.put(id, newLOD);
                }
            }
        }
    }
    
    private int calculateLOD(double distance) {
        if (distance < 20) {
            return LOD_FULL; // Entidade completa
        } else if (distance < 50) {
            return LOD_SIMPLE; // Versão simplificada
        } else {
            return LOD_MINIMAL; // Mínimo processamento
        }
    }
    
    private void applyLOD(class_1297 entity, int lod) {
        if (entity instanceof class_1308) {
            class_1308 mob = (class_1308) entity;
            
            switch (lod) {
                case LOD_FULL:
                    // Entidade normal
                    try {
                        mob.method_5977(false);
                        mob.method_5875(false);
                    } catch (Exception e) {}
                    break;
                    
                case LOD_SIMPLE:
                    // IA reduzida
                    try {
                        mob.method_5977(true);
                        mob.method_5875(false);
                    } catch (Exception e) {}
                    break;
                    
                case LOD_MINIMAL:
                    // Entidade quase estática
                    try {
                        mob.method_5977(true);
                        mob.method_5875(true);
                    } catch (Exception e) {}
                    break;
            }
        }
    }
    
    @Override
    public void shutdown() {
        entityLOD.clear();
        System.out.println("📡 [Nebula] Far Entity Simplifier desligado!");
    }
    
    @Override
    public boolean isEnabled() {
        return enabled && NebulaConfig.enableFarEntitySimplifier;
    }
}
