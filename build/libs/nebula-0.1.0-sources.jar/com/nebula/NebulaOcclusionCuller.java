package com.nebula;

import net.minecraft.class_243;
import net.minecraft.class_4076;
import net.minecraft.class_4184;

public class NebulaOcclusionCuller {

    private class_243 cameraPos;
    private final double maxDistanceSq;
    private final boolean enabled;
    private final boolean verticalCulling;

    public NebulaOcclusionCuller(class_4184 camera) {
        this.cameraPos = camera.method_19326();
        
        NebulaConfig config = NebulaConfig.get();
        this.enabled = config.enableBlockCulling;
        this.verticalCulling = config.enableVerticalCulling;

        double viewDist = config.blockCullingDistance * 16.0;
        this.maxDistanceSq = viewDist * viewDist;
    }

    public boolean isSectionVisible(class_4076 sectionPos) {
        if (!enabled) return true;

        double centerX = sectionPos.method_19527() + 8.0;
        double centerY = sectionPos.method_19528() + 8.0;
        double centerZ = sectionPos.method_19529() + 8.0;

        double dx = centerX - cameraPos.field_1352;
        double dy = centerY - cameraPos.field_1351;
        double dz = centerZ - cameraPos.field_1350;

        double distSq = dx * dx + dy * dy + dz * dz;

        if (distSq > maxDistanceSq) {
            return false;
        }

        // Culling vertical
        if (verticalCulling && Math.abs(dy) > 96 && distSq > 2304) {
            return false;
        }

        return true;
    }

    public void updateFrustum(class_4184 camera) {
        this.cameraPos = camera.method_19326();
    }
}
