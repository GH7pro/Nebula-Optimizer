package com.nebula.boost;

import com.nebula.NebulaConfig;
import com.nebula.engine.NebulaModule;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_4066;
import net.minecraft.class_5365;
import com.nebula.PerformanceMonitor;
import org.lwjgl.glfw.GLFW;

public class FPSBoostMode implements NebulaModule {
    private static final FPSBoostMode INSTANCE = new FPSBoostMode();
    private boolean enabled = true;
    private boolean isBoosted = false;
    private boolean autoBoost = false;
    private int tickCounter = 0;
    private class_304 boostKey;
    
    private static final int AUTO_BOOST_THRESHOLD = 20;
    
    private FPSBoostMode() {}
    
    public static FPSBoostMode getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "FPS Boost Mode";
    }
    
    @Override
    public void initialize() {
        System.out.println("⚡ [Nebula] FPS Boost Mode inicializado!");
        if (!NebulaConfig.enableFPSBoost) return;
        
        boostKey = new class_304(
            "key.nebula.boost",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_F,
            "key.category.nebula"
        );
        
        System.out.println("⚡ [Nebula] ✅ Pressione F para ativar/desativar o Boost");
        System.out.println("⚡ [Nebula] ✅ Boost automático em FPS < " + AUTO_BOOST_THRESHOLD);
    }
    
    @Override
    public void tick() {
        if (!enabled || !NebulaConfig.enableFPSBoost) return;
        
        class_310 client = class_310.method_1551();
        if (client == null) return;
        
        tickCounter++;
        
        if (boostKey.method_1436()) {
            if (isBoosted) {
                deactivate();
            } else {
                activate();
            }
        }
        
        if (NebulaConfig.enableAutoBoost) {
            if (tickCounter % 20 != 0) return;
            
            double fps = PerformanceMonitor.getInstance().getCurrentFPS();
            if (fps < AUTO_BOOST_THRESHOLD && !isBoosted) {
                autoBoost = true;
                activate();
            } else if (fps > AUTO_BOOST_THRESHOLD + 10 && isBoosted && autoBoost) {
                autoBoost = false;
                deactivate();
            }
        }
    }
    
    public void activate() {
        if (isBoosted) return;
        isBoosted = true;
        
        class_310 client = class_310.method_1551();
        if (client == null) return;
        
        System.out.println("⚡ [Nebula] 🔥 FPS BOOST ATIVADO!" + (autoBoost ? " (automático)" : ""));
        
        // OTIMIZAÇÕES VISUAIS (Sem mexer na View Distance para não recarregar chunks)
        client.field_1690.method_42534().method_41748(class_5365.field_25427);
        client.field_1690.method_42475().method_41748(class_4066.field_18199);
        client.field_1690.method_42435().method_41748(false);
        client.field_1690.method_42524().method_41748(60);
        client.field_1690.method_42448().method_41748(false);
        client.field_1690.method_41792().method_41748(false);
        client.field_1690.method_42528().method_41748(net.minecraft.class_4063.field_18162);
        
        System.out.println("⚡ [Nebula] 📊 FPS: 60 | Gráficos: FAST | Nuvens: OFF");
    }
    
    public void deactivate() {
        if (!isBoosted) return;
        isBoosted = false;
        autoBoost = false;
        
        class_310 client = class_310.method_1551();
        if (client == null) return;
        
        System.out.println("⚡ [Nebula] 🔄 FPS BOOST desativado!");
        
        // RESTAURA CONFIGURAÇÕES VISUAIS
        client.field_1690.method_42534().method_41748(class_5365.field_25428);
        client.field_1690.method_42475().method_41748(class_4066.field_18197);
        client.field_1690.method_42435().method_41748(true);
        client.field_1690.method_42524().method_41748(120);
        client.field_1690.method_42448().method_41748(true);
        client.field_1690.method_41792().method_41748(true);
        client.field_1690.method_42528().method_41748(net.minecraft.class_4063.field_18164);
    }
    
    public void toggle() {
        if (isBoosted) {
            deactivate();
        } else {
            activate();
        }
    }
    
    public boolean isBoosted() {
        return isBoosted;
    }
    
    public boolean isAutoBoost() {
        return autoBoost;
    }
    
    @Override
    public void shutdown() {
        if (isBoosted) deactivate();
        System.out.println("⚡ [Nebula] FPS Boost Mode desligado!");
    }
    
    @Override
    public boolean isEnabled() {
        return enabled && NebulaConfig.enableFPSBoost;
    }
}
