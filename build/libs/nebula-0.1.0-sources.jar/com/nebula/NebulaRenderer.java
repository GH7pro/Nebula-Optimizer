package com.nebula;

import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_4184;

public class NebulaRenderer {

    private final Long2ObjectOpenHashMap<NebulaChunkSection> sections = new Long2ObjectOpenHashMap<>();
    
    public final ExecutorService buildPool = Executors.newFixedThreadPool(
        Math.max(1, Runtime.getRuntime().availableProcessors() - 2),
        r -> {
            Thread t = new Thread(r, "Nebula-Builder");
            t.setDaemon(true);
            t.setPriority(Thread.NORM_PRIORITY - 1);
            return t;
        }
    );

    private NebulaOcclusionCuller blockCuller;
    private NebulaEntityCuller entityCuller;
    private int tickCounter = 0;

    public void update() {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null || client.field_1724 == null) return;

        tickCounter++;
        class_4184 camera = client.field_1773.method_19418();

        if (blockCuller == null || tickCounter % 4 == 0) {
            blockCuller = new NebulaOcclusionCuller(camera);
        } else {
            blockCuller.updateFrustum(camera);
        }

        if (entityCuller == null || tickCounter % 2 == 0) {
            entityCuller = new NebulaEntityCuller(camera);
        }

        // Reset counters
        NebulaDebug.resetCounters();

        // Entity Culling + contagem
        if (NebulaConfig.get().enableEntityCulling) {
            for (class_1297 entity : client.field_1687.method_18112()) {
                NebulaDebug.totalEntities++;
                if (!entityCuller.shouldRenderEntity(entity)) {
                    NebulaDebug.culledEntities++;
                }
            }
        }
    }

    public void clear() {
        sections.forEach((k, section) -> section.delete());
        sections.clear();
    }

    /**
     * Sem isso, o thread pool de build de chunks (buildPool) nunca era
     * desligado, e cada saída de mundo/jogo vazava threads.
     */
    public void shutdown() {
        clear();
        buildPool.shutdown();
        try {
            if (!buildPool.awaitTermination(2, java.util.concurrent.TimeUnit.SECONDS)) {
                buildPool.shutdownNow();
            }
        } catch (InterruptedException e) {
            buildPool.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
}
