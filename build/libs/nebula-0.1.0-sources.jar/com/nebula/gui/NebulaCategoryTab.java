package com.nebula.gui;

import net.minecraft.class_2561;
import net.minecraft.class_4185;

public class NebulaCategoryTab extends class_4185 {
    private String icon;
    private boolean selected = false;
    
    public NebulaCategoryTab(int x, int y, int width, int height, String icon, String text, class_4241 onPress) {
        super(x, y, width, height, class_2561.method_43470(icon + " " + text), onPress, field_40754);
        this.icon = icon;
    }
    
    public void setSelected(boolean selected) {
        this.selected = selected;
    }
    
    public boolean method_25367() {
        return selected;
    }
}
