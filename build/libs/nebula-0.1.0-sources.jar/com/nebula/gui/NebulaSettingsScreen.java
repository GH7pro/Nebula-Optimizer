package com.nebula.gui;

import com.nebula.NebulaConfig;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7842;

public class NebulaSettingsScreen extends class_437 {
    private final class_437 parent;
    private int selectedCategory = 0;
    private List<Category> categories = new ArrayList<>();
    
    private static final int HEADER_HEIGHT = 40;
    private static final int SIDEBAR_WIDTH = 180;
    private static final int SETTINGS_START_X = SIDEBAR_WIDTH + 20;
    private static final int SETTINGS_START_Y = HEADER_HEIGHT + 20;
    private static final int SETTING_SPACING = 30;
    
    private static class Category {
        String name;
        String icon;
        List<Setting> settings;
        
        Category(String name, String icon) {
            this.name = name;
            this.icon = icon;
            this.settings = new ArrayList<>();
        }
    }
    
    private static class Setting {
        String name;
        String description;
        String key;
        SettingType type;
        Object value;
        Object defaultValue;
        Object min;
        Object max;
        
        enum SettingType {
            TOGGLE, SLIDER, SELECT
        }
    }
    
    public NebulaSettingsScreen(class_437 parent) {
        super(class_2561.method_43470("Nebula Settings"));
        this.parent = parent;
        initCategories();
        initSettings();
    }
    
    private void initCategories() {
        categories.add(new Category("Entity", "👾"));
        categories.add(new Category("Blocks", "🧱"));
        categories.add(new Category("Particles", "✨"));
        categories.add(new Category("Resolution", "📐"));
        categories.add(new Category("Textures", "🖼️"));
        categories.add(new Category("Ticking", "⏱️"));
        categories.add(new Category("Chunk", "🔮"));
        categories.add(new Category("Memory", "💾"));
        categories.add(new Category("Shaders", "🎨"));
        categories.add(new Category("Battery", "🔋"));
        categories.add(new Category("Advanced", "⚡"));
        categories.add(new Category("General", "⚙️"));
    }
    
    private void initSettings() {
        NebulaConfig config = NebulaConfig.get();
        
        addSetting(0, "Entity Culling", "Oculta entidades fora do campo de visão", 
                   "enableEntityCulling", config.enableEntityCulling);
        addSetting(0, "Angle Culling", "Oculta entidades baseado no ângulo da câmera", 
                   "enableAngleCulling", config.enableAngleCulling);
        addSetting(0, "Aggressive Culling", "Culling mais agressivo (pode causar pop-in)", 
                   "enableAggressiveCulling", config.enableAggressiveCulling);
        
        addSetting(1, "Block Culling", "Oculta blocos fora do campo de visão", 
                   "enableBlockCulling", config.enableBlockCulling);
        addSetting(1, "Vertical Culling", "Oculta blocos verticalmente", 
                   "enableVerticalCulling", config.enableVerticalCulling);
        
        addSetting(2, "Particle Limit", "Limita o número de partículas", 
                   "enableParticleLimit", config.enableParticleLimit);
        
        addSetting(3, "Dynamic Resolution", "Ajusta resolução automaticamente", 
                   "enableDynamicResolution", config.enableDynamicResolution);
        
        addSetting(4, "Texture Streaming", "Carrega texturas apenas quando necessário", 
                   "enableTextureStreaming", config.enableTextureStreaming);
        
        addSetting(5, "Intelligent Ticking", "Reduz ticks de entidades distantes", 
                   "enableIntelligentTicking", config.enableIntelligentTicking);
        
        addSetting(6, "Smart Chunk Loading", "Pré-carrega chunks preditivamente", 
                   "enableSmartChunkLoading", config.enableSmartChunkLoading);
        
        addSetting(7, "Memory Management", "Gerencia RAM automaticamente", 
                   "enableMemoryManagement", config.enableMemoryManagement);
        
        addSetting(8, "Dynamic Shaders", "Ajusta qualidade de shaders dinamicamente", 
                   "enableDynamicShaders", config.enableDynamicShaders);
        
        addSetting(9, "Battery Saver", "Economiza bateria em dispositivos móveis", 
                   "enableBatterySaver", config.enableBatterySaver);
        
        addSetting(10, "Frame Prediction", "Previsão de quadros com IA", 
                   "enableFramePrediction", config.enableFramePrediction);
        addSetting(10, "Thermal Protection", "Proteção contra superaquecimento", 
                   "enableThermalProtection", config.enableThermalProtection);
        addSetting(10, "Smart Sleep", "Modo sleep quando jogador está parado", 
                   "enableSmartSleep", config.enableSmartSleep);
        
        addSetting(11, "Debug Mode", "Mostra informações de debug", 
                   "debugMode", config.debugMode);
        addSetting(11, "Show FPS", "Mostra FPS no console", 
                   "showFps", config.showFps);
    }
    
    private void addSetting(int categoryIndex, String name, String description, 
                           String key, Object currentValue) {
        Setting setting = new Setting();
        setting.name = name;
        setting.description = description;
        setting.key = key;
        setting.type = Setting.SettingType.TOGGLE;
        setting.value = currentValue;
        categories.get(categoryIndex).settings.add(setting);
    }
    
    @Override
    protected void method_25426() {
        super.method_25426();
        
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("← Back"),
            button -> this.field_22787.method_1507(parent)
        ).method_46434(10, field_22790 - 30, 80, 20).method_46431());
        
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("↺ Reset All"),
            button -> {}
        ).method_46434(field_22789 - 180, field_22790 - 30, 80, 20).method_46431());
        
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("✓ Apply"),
            button -> {}
        ).method_46434(field_22789 - 90, field_22790 - 30, 80, 20).method_46431());
        
        this.method_37063(new class_7842(
            field_22789 / 2 - 100, 10, 200, 20,
            class_2561.method_43470("⚡ Nebula Optimizer").method_27695(class_124.field_1065, class_124.field_1067),
            field_22793
        ));
    }
    
    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, field_22789, field_22790, new Color(20, 20, 30, 240).getRGB());
        context.method_25294(0, 0, field_22789, HEADER_HEIGHT, new Color(40, 40, 60, 200).getRGB());
        
        context.method_51433(field_22793, "⚡ Nebula Optimizer", 20, 14, 0xFFAA00, false);
        context.method_51433(field_22793, "v1.0.0", 20, 28, 0x888888, false);
        
        context.method_25294(0, HEADER_HEIGHT, SIDEBAR_WIDTH, field_22790, new Color(30, 30, 45, 200).getRGB());
        
        int y = HEADER_HEIGHT + 10;
        for (int i = 0; i < categories.size(); i++) {
            Category cat = categories.get(i);
            int color = (selectedCategory == i) ? 0xFFAA00 : 0x888888;
            
            if (selectedCategory == i) {
                context.method_25294(0, y, 3, y + 28, 0xFFAA00);
            }
            
            String display = cat.icon + " " + cat.name;
            context.method_51433(field_22793, display, 15, y + 8, color, false);
            y += 32;
        }
        
        int settingY = SETTINGS_START_Y;
        Category currentCat = categories.get(selectedCategory);
        
        for (Setting setting : currentCat.settings) {
            context.method_51433(field_22793, setting.name, SETTINGS_START_X, settingY, 0xFFFFFF, false);
            
            String valueStr = setting.value.toString();
            if (setting.value instanceof Boolean) {
                valueStr = (Boolean) setting.value ? "✅ ON" : "❌ OFF";
            }
            int valueColor = (setting.value instanceof Boolean && (Boolean) setting.value) ? 
                             0x55FF55 : 0xFF5555;
            context.method_51433(field_22793, valueStr, field_22789 - 120, settingY, valueColor, false);
            
            settingY += SETTING_SPACING;
        }
        
        context.method_51433(field_22793, "💡 Passe o mouse sobre uma configuração para ver a descrição", 
                         SETTINGS_START_X, field_22790 - 40, 0x888888, false);
        context.method_51433(field_22793, "🔧 " + currentCat.settings.size() + " configurações", 
                         SETTINGS_START_X, field_22790 - 25, 0x888888, false);
        
        super.method_25394(context, mouseX, mouseY, delta);
    }
    
    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (mouseX > 0 && mouseX < SIDEBAR_WIDTH && mouseY > HEADER_HEIGHT) {
            int index = (int)((mouseY - HEADER_HEIGHT) / 32);
            if (index >= 0 && index < categories.size()) {
                selectedCategory = index;
                return true;
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }
    
    @Override
    public boolean method_25421() {
        return false;
    }
}
