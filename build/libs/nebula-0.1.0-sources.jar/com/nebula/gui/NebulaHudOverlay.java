package com.nebula.gui;

import com.nebula.AdaptiveOptimizer;
import com.nebula.NebulaConfig;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * NebulaHudOverlay
 * Desenha um indicador na tela mostrando o nível de otimização do Nebula.
 * Só aparece quando o mod está atuando ativamente (Nível 1+ ou Modo Pânico).
 */
public class NebulaHudOverlay {

    public static void render(class_332 context) {
        if (!NebulaConfig.enableNebula) return;

        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null || client.field_1690.field_1842) return;

        AdaptiveOptimizer optimizer = AdaptiveOptimizer.getInstance();
        if (optimizer == null) return;

        int level = optimizer.getCurrentOptimizationLevel();
        boolean panic = optimizer.isInPanicMode();

        // Se não está em pânico e o nível é 0, não desenha nada na tela (jogo rodando bem)
        if (!panic && level == 0) return;

        String text;
        int color;

        if (panic) {
            // Efeito de "piscar" rápido no modo pânico
            long time = System.currentTimeMillis() / 250; // Muda a cada 0.25 segundos
            if (time % 2 == 0) {
                text = "🚨 NEBULA: PÂNICO 🚨";
                color = 0xFF5555; // Vermelho claro
            } else {
                text = "   NEBULA: PÂNICO   ";
                color = 0xFFFFFF; // Branco
            }
        } else {
            text = "⚡ NEBULA: NÍVEL " + level;
            color = 0xFFAA00; // Amarelo/Laranja
        }

        // Posição: Canto superior esquerdo, um pouco abaixo da hotbar de FPS do vanilla
        int x = 10;
        int y = 10;

        // Desenha o texto com sombra para não sumir no fundo claro
        context.method_27535(client.field_1772, class_2561.method_43470(text), x, y, color);
    }
}
